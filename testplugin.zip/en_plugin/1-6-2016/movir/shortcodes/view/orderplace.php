<?php
	require_once('config.php');
	$vehicle_type_option = array(
							1=>'Mini Van',
							2=>'Pickup Truck',
							3=>'Truck',
							4=>'Motorcycle',
							5=>'Sedan'
//							0=>'Don\'t Know ?'
						);
	$order_type_option = array(
							1=>'No Lugging',
							2=>'Lugging',
						);
						
	$elevetor_option =  array('type'=>'array',
						'contant'=>array(
							''=>'Floor/Elevator',
							'-1'=>'Elevetor',
							0=>'Ground Floor',
							1=>'1st Floor',
							2=>'2nd Floor',
							3=>'3rd Floor',
							4=>'4th Floor',
							5=>'5th Floor',
						)
					);
					
	$Form = new movir_Form();

	function createNextStepButton($step,$label = '{{ "Next" | translate }}'){
		if(! (isset($step) && is_numeric($step))){ return false; }
		$Form = new movir_Form();
		$html = $Form->Button('button','nextStep_'.$step,$label,'nextbtn',array('ng-click'=>'nextstep('.$step.')'));
		return $html;
	}
?>

<div class="tabcontainer">
	<div class="row" ng-class="{'no-lugging': ordertype==1, 'lugging': ordertype==2}" style="visibility:visible;"><!--style="visibility:hidden;"-->
	
	<?php echo $Form->Open(false,false,'form',array('onsubmit'=>'return false;','enctype'=>'multipart/form-data')); ?> 
	<div class="col-xs-12">
		<uib-accordion close-others="oneAtATime">
			<!-- Step 1 -->
			<uib-accordion-group heading="{{ 'LOCATIONANDTIME' | translate }}" is-open="openStep == 1" is-disabled="complatedStep < 1" id="step1">
				<div class="row">
					<div class="col-sm-12"><uib-progressbar value="33" type="success">33%</uib-progressbar></div>
				</div>
				<div class="row">
					<script>
								jQuery(function () {
									
									jQuery("#pickupphone").mask("999-9999999");
									jQuery("#dropphone").mask("999-9999999");
									
									jQuery(".dateicon").click(function () {
										jQuery('#appointmentdate1').focus();
									});
									jQuery(".timeicon").click(function () {
										jQuery('#appointmenttime1').focus();
									});
									
									jQuery('#appointmentdate','#movirAppCtrl').datetimepicker({
										format:'MM-DD-YYYY HH:mm',
										
										
									}).on('dp.hide',function(e){
										var date = jQuery(this).val();
										//angular.element(document.getElementById('appointmentdate1')).scope().checkAppointmentDate(date);
										var scope = angular.element(document.getElementById('movirAppCtrl')).scope();
											scope.$apply(function(){
												scope.$$childHead.checkAppointmentDate(date);
												
											});
									});
									jQuery('#appointmentdate1','#movirAppCtrl').datetimepicker({
									  format:'MM-DD-YYYY',
									 // minDate: moment(),
									  //startDate: new Date(),
									}).on('dp.change',function(e){
										
										var time1 = jQuery('#appointmenttime1').val();
										if(time1 == ""){
											//alert("Please enter Date");
											//jQuery('#movir_error_step_1').text("Please enter Time");
											//return false;
										}else{
											var date1 = jQuery('#appointmentdate1').val();
											var date = date1+" "+time1;
											var datetest = jQuery('#appointmentdate').val(date);
											var scope = angular.element(document.getElementById('movirAppCtrl')).scope();
											scope.$apply(function(){
												scope.$$childHead.checkAppointmentDate(date);

											});
										}
									});
									jQuery('#appointmenttime1','#movirAppCtrl').datetimepicker({
									  format:'HH:mm',
									  stepping: 30
									 
									}).on('dp.change',function(e){
										
										var date1 = jQuery('#appointmentdate1').val();
										if(date1 == ""){
											//alert("Please enter Date");
											jQuery('#movir_error_step_1').text("Please enter Date");
											return false;
										}else{
											var time1 = jQuery('#appointmenttime1').val();
											var date = date1+" "+time1;
											var datetest = jQuery('#appointmentdate').val(date);
											var scope = angular.element(document.getElementById('movirAppCtrl')).scope();
											scope.$apply(function(){
												scope.$$childHead.checkAppointmentDate(date);

											});
										}
									});
								});
								
								function init() {
									
									var pickupaddress = document.getElementById('pickupaddress');
									//alert(pickupaddress);
									
									var dropaddress = document.getElementById('dropaddress');
									
									
									if(pickupaddress){
										
										var autocomplete_pickupaddress = new google.maps.places.Autocomplete(pickupaddress);
										autocomplete_pickupaddress.addListener('place_changed', function() {
											//var place = autocomplete_pickupaddress.getPlace();
											var scope = angular.element(document.getElementById('movirAppCtrl')).scope();
											scope.$apply(function(){
												scope.$$childHead.setPickupAddress(pickupaddress.value);
												
											});
										});
									}
									if(dropaddress){
										var autocomplete_dropaddress = new google.maps.places.Autocomplete(dropaddress);	
										autocomplete_dropaddress.addListener('place_changed', function() {
											//var place = autocomplete_dropaddress.getPlace();
											var scope = angular.element(document.getElementById('movirAppCtrl')).scope();
											scope.$apply(function(){
												scope.$$childHead.setDropAddress(dropaddress.value)
											});
										});
									}
								}
					 
								google.maps.event.addDomListener(window, 'load', init);
								initMap(init);
								
					</script>
					<!--<div class="ordertype-list" >
						<div class="form-group">
							<label ng-repeat="type in resource.ordertype" class="cbx-label" ng-class="{ 'active':order.ordertype==type.value }">
								<input type="radio" ng-model="order.ordertype" value="{{ type.value }}" id="ordertype" name="ordertype" ><span>{{ type.text | translate }}</span>
							</label>	
						</div>
						<div class="clear"></div>
					</div>-->
					<div style="margin-top:10px" class="needl btn btn-warning"> 
							<label class="orderstep">
								{{'Needlugging?(doortodoor)' | translate}}
							</label>
							
							<input type="checkbox" ng-model="order.ordertype" value="order.ordertype" id="ordertype" name="ordertype" class="pull-right" ng-true-value="2" ng-false-value="1" ng-init="order.ordertype=1">
							
							<label class="checkbox" for="ordertype" style="float:right"></label>
						</div>
						<!--<div>{{order.ordertype}}</div>-->
						<div class="clear"></div>
					<div class="row">
					<!--<div class="col-xs-12"><p id="movir_error_step_2" class="text-danger error-message" ng-bind="message[2]"></p></div>-->
					<div class="col-xs-12 text-center vehicletype-list form-group" ng-hide="true">
						<div class="form-group">
							<label ng-repeat="type in resource.vehicletype" class="cbx-label" ng-class="{ 'active': type.value==order.vehicletype }">
								<input type="radio" ng-model="order.vehicletype" value="{{ type.value }}" id="vehicletype" name="vehicletype" ><span>{{ type.text | translate }}</span>
							</label>
						</div>
					</div>
					<div class="clear"></div>
					<!--<hr class="" ng-hide="true"/>-->
					<hr>
					<div class="col-xs-12"><p id="movir_error_step_1" class="text-danger error-message text-center" ng-bind="message[1]"></p></div>
					<?php /*?><div class="col-xs-12"><?php echo $Form->Input('text','pickupaddress','','',false,array('ng-change'=>'setPickupAddress(this)','placeholder'=>'Pickup Address','ng-model'=>'pickAddress')); ?></div><?php */?>
					<h5>{{'PickupInfo' | translate}}</h5>
					
					<div class="col-xs-12">
						<div class="row">
							<!--<div class="col-xs-6">
								<?php //echo $Form->Input('text','pickupname','','',false,array('placeholder'=>"{{ 'FullName' | translate }}",'ng-model'=>'order.pickupname')); ?>
							</div>-->
							<div class="col-xs-12">
								<?php echo $Form->Input('text','pickupphone','','',false,array('placeholder'=>"{{ 'PhoneNumber' | translate }}",'ng-model'=>'order.pickupphone','id'=>'pickphone')); ?>
								<label  class="phnumber icon-addoniput" ></label>
							</div>
							<div class="col-xs-12">
								<?php echo $Form->Input('text','pickupaddress','','',false,array('placeholder'=>"{{ 'PickupAddress' | translate }}",'ng-model'=>'order.pickAddress')); ?>
								
								<label  class="pickupicon icon-addoniput" ></label>
                                 <label  class="pickupright icon-addonright" ></label>
								<p  class="text-danger error-message" ng-bind="message['pickupcity']"></p>
							</div>
							<!--<input id="locationTextField" type="text" size="50">-->
							 
							
							<?php /*?><div class="col-xs-6"><h4>Add Items for move</h4></div> <?php */?>
							
						</div>
						
					</div>
				</div>
				<!-- Order Hire Pro -->
				<!--<div id="orderhirepro" class="orderhirepro " ng-hide="order.ordertype!=2">-->
					<div id="orderhirepro" class="orderhirepro " ng-show="order.ordertype" ng-hide="order.ordertype!=2">
					<div class="row text-center assembly-line">
						
						<!--<div class="col-xs-4">
							<?php echo $Form->Input('text','pickFloor',false,false,'',array('placeholder'=>"{{ 'FloorNumber' | translate }}",'ng-model'=>'order.pickFloor'),array(),array('required'=>false)); ?>
							 <label  class="floor icon-addoniput" ></label>
						</div>-->
						<div class="col-lg-6">
							<div class="form-group">
								<select ng-model='order.pickFloor'  required>
									<option value="">Select Floor/Elevator</option>
									<option value="Elevator">Elevetor</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="4">5</option>
									<option value="6">6</option>
									<option value="7">7</option>
									<option value="8">8</option>
									<option value="9">9</option>
									<option value="10">10</option>
									<option value="11">11</option>
									<option value="12">12</option>
									<option value="13">13</option>
									<option value="14">14</option>
									<option value="15">15</option>
									
								</select>
							</div>
							<label  class="floor icon-addoniput" ></label>
							 <!--<span>{{order.pickFloor}}</span>-->
						</div>
						<!--<div class="col-xs-4">
							<div class="form-group"><label class="cbx-label" ng-class="{ 'active':order.pickupElevator==1 }">
								<input type="checkbox" ng-false-value="0" ng-true-value="1" ng-model="order.pickupElevator" value="1" id="pickupElevator[1]" name="pickupElevator[1]" class="ng-untouched ng-valid ng-dirty ng-valid-parse" style=""><span>{{ 'IsthereanElevator' | translate }}</span></label></div>
							<?php //echo $Form->Checkbox('pickupElevator',array(),'','',array('ng-model'=>'order.pickupElevator','ng-true-value'=>'1','ng-false-value'=>'0'),array(),array('1'=>'Pickup Elevator'),array('required'=>false)); ?>
						</div>-->
						<div class="col-lg-6">
							<div class="form-group">
                            	<!--<label class="cbx-label" ng-class="{'active':order.isAssembly==1}"><input type="checkbox" ng-false-value="0" ng-true-value="1" ng-model="order.isAssembly" value="1" id="isAssembly[1]" name="isAssembly[1]" class="ng-untouched ng-valid ng-dirty ng-valid-parse" style=""><span>{{ 'Assembly' | translate }}</span></label>-->
                                 <label class="cbx-label " style="" ng-class="{'active':order.isAssembly==1}">{{ 'Assembly' | translate }}</label>
                                <input id="isAssembly[1]" class="ng-untouched ng-valid ng-dirty ng-valid-parse" type="checkbox" ng-false-value="0" ng-true-value="1" ng-model="order.isAssembly" value="1" name="isAssembly[1]" style="">
								<label class="checkbox" for="isAssembly[1]" style="position: relative; top: -35px; left: -79px;" id="asschk"></label>
                            </div>
							<?php //echo $Form->Checkbox('isAssembly',array(),'','',array('ng-model'=>'order.isAssembly','ng-true-value'=>'1','ng-false-value'=>'0'),array(),array('1'=>'Assembly ?'),array('required'=>false)); ?>
						</div>
					</div>
				</div>
				<div class="row">
					<h5>{{'DropoffInfo' | translate}}</h5>
					<!--<div class="col-xs-12"><p id="movir_error_step_3" class="text-danger error-message" ng-bind="message[3]"></p></div>-->
					<!--<div class="col-xs-6">
						<?php //echo $Form->Input('text','dropname','','',false,array('placeholder'=>"{{ 'FullName' | translate }}",'ng-model'=>'order.dropname')); ?>
					</div>-->
					<div class="col-xs-12">
						<?php echo $Form->Input('text','dropphone','','',false,array('placeholder'=>"{{ 'PhoneNumber' | translate }}",'ng-model'=>'order.dropphone','id'=>'dropphone')); ?>
						<label  class="phnumber icon-addoniput" ></label>
					</div>
					<div class="col-xs-12">
						<?php echo $Form->Input('text','dropaddress','','',false,array('placeholder'=>"{{ 'DropoffAddress' | translate}}",'ng-model'=>'order.dropAddress')); ?>
						<label  class="dropicon icon-addoniput" ></label>
                         <label  class="pickupright icon-addonright" ></label>
                         <p  class="text-danger error-message" ng-bind="message['dropcity']"></p>
						</div>
					<div class="col-xs-12">
						<div class="row assembly-line text-center " ng-show="order.ordertype" ng-hide="order.ordertype!=2"> <!-- .column-5 -->
							
							<!--<div class="col-xs-6">
								<?php echo $Form->Input('text','dropFloor','','','',array('placeholder'=>"{{ 'FloorNumber' | translate }}",'ng-model'=>'order.dropFloor'),array(),array('required'=>false)); ?>
								<label  class="floor icon-addoniput" ></label>
								</div>
							<div class="col-xs-6">
								<div class="form-group">
									<label class="cbx-label" ng-class="{'active': order.phpdropElevator==1 }"><input type="checkbox" ng-false-value="0" ng-true-value="1" ng-model="order.phpdropElevator" value="1" id="dropElevator" name="dropElevator" class="" ><span>{{ 'IsthereanElevator' | translate }}</span></label>
								</div>
								<?php //echo $Form->Checkbox('dropElevator',array(),'','',array('ng-model'=>'order.phpdropElevator','ng-true-value'=>'1','ng-false-value'=>'0'),array(),array('1'=>'Drop Elevator'),array('required'=>false)); ?>
							</div>-->
							
						<div class="col-xs-6">
							<div class="form-group">
								<select ng-model='order.dropFloor'  required>
									<option value="">Select Floor/Elevator</option>
									<option value="Elevator">Elevetor</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="4">5</option>
									<option value="6">6</option>
									<option value="7">7</option>
									<option value="8">8</option>
									<option value="9">9</option>
									<option value="10">10</option>
									<option value="11">11</option>
									<option value="12">12</option>
									<option value="13">13</option>
									<option value="14">14</option>
									<option value="15">15</option>
									
								</select>
							</div>
							<label  class="floor icon-addoniput" ></label>
							 <!--<span>{{order.dropFloor}}</span>-->
						</div>
						</div>
					</div>
					<h5>{{'OrderTime' | translate}}</h5>
						<div class="col-sm-12">
								<?php echo $Form->Input('hidden','appointmentdate',false,false,'',array('placeholder'=>"{{ 'AppointmentDate' | translate }}",'ng-model'=>'order.appointmentdate'),array(),array()); ?>
								<!--<label  class="dateicon" ></label>-->
							</div>
							
							<div class="col-xs-12"><p id="movir_error_step" class="text-danger error-message text-center" ng-bind="datetimeerror"></p></div>
							<div class="col-sm-12 datetime">
								<div class="col-sm-6 dateslot">
										<?php echo $Form->Input('text','appointmentdate1',false,false,'',array('placeholder'=>"{{'Date'| translate}}",'ng-model'=>'order.appointmentdate1')); ?>
										<label  class="dateicon" ></label>
								</div>
								<div class="col-sm-6 timeslot">
										<?php echo $Form->Input('text','appointmenttime1',false,false,'',array('placeholder'=>"{{'Times' | translate}}",'ng-model'=>'order.appointmenttime1')); ?>
										<label  class="timeicon" ></label>
								</div>
							</div>
                            <div class="checkdateloading"></div>
						
							
				</div>
					<div class="col-xs-12 text-right"><?php echo createNextStepButton(2); ?></div>
				</div>
			</uib-accordion-group>
			<!-- /Step 1 -->
			<!-- Step 2 -->
			<uib-accordion-group heading="{{ 'ORDER DETAILS' | translate }}" is-open="openStep == 2" is-disabled="complatedStep < 2" id="step2" class="hide"> 
				<div class="row">
					<div class="col-sm-12"><uib-progressbar value="66" type="success">66%</uib-progressbar></div>
				 </div>
				 <div class="col-xs-12"><p id="movir_error_step_2" class="text-danger error-message text-center" ng-bind="message[2]"></p></div>
				<div class="col-xs-12">
								<div id="auto" style="display:none;"><?php echo $Form->Input('text','searchproduct','',' typeahead tt-query tags ',false,array('placeholder'=>"{{ 'AddItems' | translate }}",'ng-model'=>'productSearchQuery','autocomplete'=>'off'),array(),array('required'=>false)); //  ?></div>
								<button class="btn btn-warning" style="width:100%;" id="btn" type="button"  > Add item +</button>
								<p  class="text-danger error-message" ng-bind="message['product']"></p>
							</div>
				<div class="table-responsive" style="width:100%">			
				<table class="table table-condensed ">
							<thead>
								<tr><th width="20%">Image</th><th width="20%" ng-hide="order.ordertype!=2 || order.isAssembly!=1">{{ 'Assembly1' | translate }}</th><th>{{ 'ProductName' | translate }}</th><th width="20%">{{ 'Remove' | translate }}</th></tr>
							</thead>
							<tbody>
								<tr ng-repeat="x in order.product" ng-row="{{x.id}}">
									<td >
									
									<div class="form-group ">
										<!--<div>
                                        <div><input type="file" id="fileInput" /></div>
                                          <div class="cropArea">
                                            <img-crop image="myImage" result-image="myCroppedImage"></img-crop>
                                          </div>
                                          <div>Cropped Image:</div>
                                          <div><img ng-src="{{myCroppedImage}}" /></div>
                                        </div>-->
										<div class="col-md-12">
											<div class="fileinput fileinput-new" data-provides="fileinput">
												<div class="fileinput-preview thumbnail iu" data-trigger="fileinput" >
												<img ng-src="{{x.image}}" alt=""/>
												</div>
												<div>
													<span class="btn btn-file">
													
													<input type="file" id="upload" ng-file-select="onFileSelect($files,x.id)" required>
													</span>
													
												</div>
                                                <!--<div class="progress"></div>-->
                                               <div class="progress_{{x.id}}" style="margin-bottom: 0;" id="imgprogressbar">
                                                    
                                                </div>
                                                
                                                
											</div>
											
										</div>
									</div>
									</td>
									<td ng-hide="order.ordertype!=2 || order.isAssembly!=1"><input type="checkbox" ng-model='x.assemble' ng-click="addAssembly(x.id)"></td>
									<td style="float:none">{{ x.name }}</td>
									<td class=""><a href="javascript:" ng-click="removeProduct(x.id)" class="btn-xs text-danger" ng-value="{{x.id}}"><i class="fa fa-times"></i></a> </td>
								</tr>
							</tbody>
						</table>
						</div>
                        
						
				<div class="row">
					<!--a href="javascript:" ng-file-select="onFileSelect($files)" class="btn-xs text-danger" >add image</a-->
					<hr>
					<div class="col-xs-12 text-center">
						<?php  echo createNextStepButton(1,'{{ "Back" | translate }}'); ?>
						<?php  echo createNextStepButton(3); ?>
					</div>
				</div>
				<!-- /Order Hire Pro -->
			</uib-accordion-group>
			<!-- /Step 2 -->
			<!-- Step 3 -->
			<uib-accordion-group heading="{{ 'PAYMENT & ORDER' | translate }}" is-open="openStep == 3" is-disabled="complatedStep < 3" id="step3" class="hide">
				<div class="row">
					<div class="col-sm-12"><uib-progressbar value="100" type="success">100%</uib-progressbar></div>
				 </div>
				<p id="movir_error_step_3" class="text-danger error-message" ng-bind="message[3]"></p>
				<div id="estimateCharge" class="row"  ng-hide="estimateCharge == false" > <!-- ng-bind='estimateCharge.html' -->
					
					<!--<div class="col-sm-12">
								<?php echo $Form->Input('text','appointmentdate',false,false,'',array('placeholder'=>"{{ 'AppointmentDate' | translate }}",'ng-model'=>'order.appointmentdate'),array(),array('required'=>false)); ?>
							</div>-->
					<div class="col-xs-12" style="padding:15px">
						<!--<div class="col-xs-6 pull-left creditinfo">{{ 'ADDCREDITCARD' | translate }}</div>-->
						<div class="col-xs-12 pull-right creditoption" ng-hide="estimateCharge == false">
								<?php echo $Form->Button('button','btnAddPayment',"{{ 'AddCreditCard' | translate }}",'btn-warning addcredit',array('ng-click'=>'getCcDetailId()','data-loading-text'=>"{{ 'Loading' | translate }}")) ?>
						</div>
                        
					</div>
					<div class="col-xs-12">
						<?php 
							$coupon_html = array();
							$coupon_html['before_control'] = '<div class="input-group">';
							$coupon_html['after_control'] = '<span class="input-group-btn"><button class="btn btn-info" ng-hide="couponverified == true" ng-click="verifyCoupon();" type="button">{{ "VERIFY" | translate }}</button></span>
								<label  class="coupicon" ></label>
							</div>';
							echo $Form->Input('text','EnterCouponCode',false,false,'',array('placeholder'=>"{{ 'Coupon' | translate }}",'ng-disabled'=>'couponverified == true','ng-model'=>'order.coupon'),$coupon_html,array('required'=>false)); 
						?>
					</div>
					<div class="col-xs-12" style="padding:15px" ng-hide="order.ordertype==1">
						<div class="col-xs-10 pull-left ordertypeinfo">{{ 'Needlugging?(doortodoor)' | translate }}</div>
						<div class="col-xs-2 pull-right orderoption">{{(order.ordertype==1?'NO':'YES')}}</div>
					</div>
					<div class="col-xs-12" style="padding:15px">
						<div class="col-xs-6 pull-left orderdatetimeinfo">{{ "DateANDTime" | translate }}</div>
						<div class="col-xs-6 pull-right orderdatetime">
							<span ng-bind="order.appointmentdate"></span>
						</div>
						
					</div>
					<div class="col-xs-12">
						<div>
							
							<div class="addressname">{{ "PickupAddress" | translate }}</div>
							
							<div class="addressinfo">
								<div ng-show="order.ordertype" ng-hide="order.ordertype!=2" class="floor1">
									<span ng-show="order.pickFloor!='Elevator'">{{ "FloorNumber" | translate }} : 
									<large >{{ (order.pickFloor=='Elevator'?0:order.pickFloor) }}</large>
                                    </span>
                                    <span ng-show="order.pickFloor=='Elevator'">
									{{ "Elevator" | translate }} : 
									<large >{{ (order.pickFloor=='Elevator'?'YES':'NO') }}</large>
                                    </span>
								</div>
								
								<div ng-bind="order.pickAddress"></div>
								
							</div>
							
						</div>
					</div>
					<div class="col-xs-12">
						<div>
							
							<div class="addressname">{{ "DropoffAddress" | translate }}</div>
							
							<div class="addressinfo">
								<div ng-show="order.ordertype" ng-hide="order.ordertype!=2" class="floor1">
									<span ng-show="order.dropFloor!='Elevator'">{{ "FloorNumber" | translate }} : 
                                    <large >{{ (order.dropFloor=='Elevator'?0:order.dropFloor) }}</large>
                                    </span>
                                    <span ng-show="order.dropFloor=='Elevator'">
                                    {{ "Elevator" | translate }} : 
									<large >{{ (order.dropFloor=='Elevator'?'YES':'NO') }}</large>
                                    </span>
                                    </div>
								
								<div ng-bind="order.dropAddress"></div>
								
								</div>
						</div>
					</div>
					<!--<div class="col-xs-12">
						<address>
							<strong>{{ "DropoffAddress" | translate }}</strong><br>
							<span ng-bind="order.dropAddress"></span><br>
							<span ng-show="order.ordertype" ng-hide="order.ordertype!=2" >{{ "FloorNumber" | translate }} : <small> {{ (isNaN(order.dropFloor)?0:order.dropFloor) }} </small>,  {{ "Elevator" | translate }} : <small>{{ (order.dropElevator==1?'YES':'NO') }}</small></span>
						</address>
					</div>-->
					<div class="clear"></div>
					<hr style="border-color:#ccc !important">
					<div class="col-xs-12">
						<table class="table">
							<tbody>
								<tr>
									<!--<th>#</th>-->
									<th>{{ 'ALLITEMS' | translate }}</th>
									<th ng-hide="order.isAssembly != 1">{{ 'Assembly' | translate }}</th>
								</tr>
								<tr ng-repeat="pro in order.product">
									<!--<td>{{ pro.index }}</td>-->
									<td>{{ pro.name }}</td>
									<td ng-hide="order.isAssembly != 1">{{ (pro.assemble?'YES':'NO') }}</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="col-xs-12 pull-right summary">
						<div class="floor1 summary-heading">{{ 'OrderSummary' | translate }}</div>
						<dl class="dl-horizontal">
							<!--<dt>{{ 'MovingCharge' | translate }}</dt>
							<dd><span ng-bind="estimateCharge.transport_charge"></span>&nbsp;<small>ILS</small></dd>-->
							<dt>{{ 'CouponDiscount' | translate }}</dt>
							<dd><span ng-bind="estimateCharge.discount"></span>&nbsp;<small>ILS</small></dd>
							<dt>{{ 'VAT' | translate}} (<span ng-bind="estimateCharge.vat_percentage"></span>%)</dt>
							<dd><span ng-bind="estimateCharge.vat"></span>&nbsp;<small>ILS</small></dd>
							<hr style="border:color:#ccc -moz-use-text-color -moz-use-text-color">
							<dt>{{ 'Total' | translate }}</dt>
							<dd><span ng-bind="estimateCharge.price"></span>&nbsp;<small>ILS</small></dd>
						</dl>
					</div>
                    <div class="col-xs-12" style="margin-top:25px">
				  <textarea rows="3" placeholder="{{ 'CommentForMover' | translate }}"></textarea>
				</div>
				</div>
				
				
				<div class="row clear">
					
					<div class="text-center">
						<?php echo createNextStepButton(2,'{{ "Back" | translate }}'); ?>
						<?php echo $Form->Button('button','btnMovirSubmit',"{{ 'OrderYourMoverNow' | translate }}",'btn btn-info nextbtn',array('data-loading-text'=>"{{ 'Loading' | translate }}",'ng-click'=>'placeOrder()')); ?>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-12 text-right">
						<?php  //echo createNextStepButton(2,'{{ "Back" | translate }}'); ?>
						<?php  //echo createNextStepButton(4,'{{ "GetEstimate" | translate }}'); ?>
					</div>
				</div>
			</uib-accordion-group>
			<!-- /Step 3 -->
			
		</uib-accordion>
	</div>
	</div>
<?php echo $Form->Close(); ?>
	<div id="movir_OrderPaymentModal" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<?php /*?><div class="modal-header"><h4 class="modal-title">Modal title</h4></div><?php */?>
              
				<div class="modal-body">
					<iframe id="iframeOrderPayment" class="iframeOrderPayment" src="" name="iframecc"></iframe>
				</div>
                <div class="modal-footer" style="text-align: center !important"><button class="btn btn-warning " aria-hidden="true" data-dismiss="modal" type="button" id="modalok">OK</button></div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
</div>

<script type="text/javascript">
	
function initMapDirection(){
	//alert(11);
	
	var pickupaddress = document.getElementById('pickupaddress');
	//alert(pickupaddress);
	
	var dropaddress = document.getElementById('dropaddress');
	
	
	if(pickupaddress){
		
		var autocomplete_pickupaddress = new google.maps.places.Autocomplete(pickupaddress);
		autocomplete_pickupaddress.addListener('place_changed', function() {
			//var place = autocomplete_pickupaddress.getPlace();
			var scope = angular.element(document.getElementById('movirAppCtrl')).scope();
			scope.$apply(function(){
				scope.$$childHead.setPickupAddress(pickupaddress.value);
				
			});
		});
	}
	if(dropaddress){
		var autocomplete_dropaddress = new google.maps.places.Autocomplete(dropaddress);	
		autocomplete_dropaddress.addListener('place_changed', function() {
			//var place = autocomplete_dropaddress.getPlace();
			var scope = angular.element(document.getElementById('movirAppCtrl')).scope();
			scope.$apply(function(){
				scope.$$childHead.setDropAddress(dropaddress.value)
			});
		});
	}
}

</script>
<script type="text/javascript">
    		//var url = document.getElementById("iframeOrderPayment").src;
			//alert(url);
    	</script>
