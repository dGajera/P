<p class="text-center" ng-bind="message[0]" style="padding:20px;color:#fff"></p>
<div class="">
	<div class="form-group" ng-if='order.status'>
		<ul class="list-inline text-center live-track-list">
			<li>
				<label class="label step step-1" ng-class="{'active':order.status>=6}" ></label>
				<span ng-bind="order.status_date_string[6]"></span>
			</li>
			<li>
				<label class="label step step-2" ng-class="{'active':order.status>=7}" ></label>
				<span ng-bind="order.status_date_string[7]"></span>
			</li>
			<li>
				<label class="label step step-3" ng-class="{'active':order.status>=8}" ></label>
				<span ng-bind="order.status_date_string[8]"></span>
			</li>
			<li>
				<label class="label step step-4" ng-class="{'active':order.status>=9}" ></label>
				<span ng-bind="order.status_date_string[9]"></span>
			</li>
		</ul>
	</div>
	<!--<div class="col-xs-6 col-xs-offset-3 padding-xs">
		<input type="button" class="btn btn-danger btn-block" value="{{ 'AdditionalServices' | translate }}" ng-hide="order.order_type == 2" data-toggle="modal" data-target="#modalAdditionalServices">
	</div>-->
	<div class=""><div id="mapLivetrack" class="mapLivetrack"></div></div>
	
	<div class="driverdetail margin-top-sm row" ng-if="order.mobile">
		<div class="col-sm-3">
			<a href="javascript:" class="thumbnail"><img src="{{ order.profile_pic }}" alt="{{ order.mas_name }}"></a>
		</div>
		<div class="col-sm-6 pull-right">
			<dl class="dl-horizontal">
				<dt class="text-theme" ><label>{{ 'FullName' | translate }}</label> : </dt><dd><span ng-bind="order.mas_name" ></span></dd>
				<dt class="text-theme" ><label>{{ 'PhoneNumber' | translate }}</label> : </dt><dd><span ng-bind="order.mobile" ></span></dd>
				<dt class="text-theme" ><label>{{ 'DriverRating' | translate }}</label> : </dt><dd><span ng-bind="order.driverrating" ></span></dd>
                <!--<dt class="text-theme" ><label>{{ 'Profile Pic' | translate }}</label> : </dt><dd><img ng-src="{{order.profile_pic}}" width="70px"></dd>-->
                
			</dl>
		</div>
	</div>
</div>


<!--  Additional services modal  -->
<div id="modalAdditionalServices" class="modal fade" tabindex="-1" role="dialog" ng-hide="order.order_type != 2">
	<div class="modal-dialog">
		
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">Add Product for Assemble</h4>
			</div>
			<div class="modal-body">
				<p class="text-danger" ng-bind="message[1]"></p>
				<ul class="orderlisting">
					<li ng-repeat="product in product_list "  >
						<ul class="list-item ">
							<li><label class="label " ><img src="{{ product.image }}" alt="{{ product.product_name }}"></label></li>
							<li><p><label class="text-theme text-bold"> Name : {{ product.product_name }}</label></p> {{ product.product_id }}</li>
							<li><input type="checkbox" id="assemble_product" name="assemble_product" ng-model="assemble_product" value="{{ product.product_id }}"> </li>
						</ul>
					</li>
				</ul>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button id="btnSubmitAdditionalServices" data-loading-text="Loading..." type="button" class="btn btn-info btn-theme" ng-click="submitAdditionalServices()">Save changes</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->
