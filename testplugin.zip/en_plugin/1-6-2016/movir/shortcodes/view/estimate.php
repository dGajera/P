<?php
	$vehicle_type_option = array(
							1=>'Mini Van',
							2=>'Pickup Truck',
							3=>'Truck',
//							0=>'Don\'t Know ?'
						);
	$order_type_option = array(
							1=>'No Lugging',
							2=>'Lugging',
						);
						
	$elevetor_option =  array('type'=>'array',
						'contant'=>array(
							''=>'Floor/Elevator',
							'-1'=>'Elevetor',
							0=>'Ground Floor',
							1=>'1st Floor',
							2=>'2nd Floor',
							3=>'3rd Floor',
							4=>'4th Floor',
							5=>'5th Floor',
						)
					);
					
	$Form = new movir_Form();

	function createNextStepButton($step,$label = 'Next Step'){
		if(! (isset($step) && is_numeric($step))){ return false; }
		$Form = new movir_Form();
		$html = $Form->Button('button','nextStep_'.$step,$label,'btn btn-info',array('ng-click'=>'nextstep('.$step.')'));
		return $html;
	}
?>
<div class="row" id="movirApp" data-ng-app="movir" ng-controller="movirEstimateController" ng-class="{'no-lugging': ordertype==1, 'lugging': ordertype==2}" style="visibility:hidden;"><!--style="visibility:hidden;"-->
	<?php /*?><div class="col-xs-12"><h3 class="text-white movir-app-title">Check the cost of your move.</h3></div><?php */?>
	<div class="">
		<?php echo $Form->Open(false,false,'form',array('onsubmit'=>'return false;')); ?>
		<div class="homebox ">
			<div class="row" style="margin-bottom: 15px;">
				<div class="col-md-3 text-left"><p class="col-xs-12">Do you need lugging?</p></div>
				
			</div>
			<div class="row">
				<div class="col-sm-12 form-container">
					<div class="col-md-3 ordertype-list">
						<?php echo $Form->Radio('ordertype',false,'','',array('ng-model'=>'ordertype','ng-click'=>'setOrderType(this)'),array(),$order_type_option); ?>
					</div>
					<div class="col-md-7">
						<div class="row">
							<div class="padding-0 col-md-6"  >
								<?php
									$floorDropdown = $Form->Dropdown('pickFloor',0,'text-input tooltips','',array('placeholder'=>'Pickup Floor','ng-model'=>'pickFloor'),array(),$elevetor_option,array('required'=>false));
									$html_attr = array(
										'before_control' => '<div class="input-group"><div class="input-group-addon"><i class="fa fa-truck fa-flip-horizontal"></i></div>',
										'after_control' => '<span class="input-group-addon dropdown-container" ng-hide="ordertype!=2">'.$floorDropdown.'</span></div>',
									);
									echo $Form->Input('text','pickupaddress','','',false,array('ng-blur'=>'pickupaddress_blur();','placeholder'=>'Pickup Address','ng-model'=>'pickAddress'),$html_attr);
								?>
							</div>
							<div class="padding-0 col-md-6" > 
								<?php
									$floorDropdown = $Form->Dropdown('dropFloor',false,'text-input tooltips','',array('ng-change'=>'setDropFloor(this)','placeholder'=>'Drop Floor','ng-model'=>'dropFloor'),array(),$elevetor_option,array('required'=>false));
									$html_attr = array(
										'before_control' => '<div class="input-group"><div class="input-group-addon"><i class="fa fa-truck "></i></div>',
										'after_control' => '<span class="input-group-addon dropdown-container" ng-hide="ordertype!=2">'.$floorDropdown.'</span></div>',
									);
									echo $Form->Input('text','dropaddress','','',false,array('placeholder'=>'Drop Address','ng-model'=>'dropAddress'),$html_attr); 
								?>
							</div>
						</div>
					</div>
					
					
					<div class="col-md-2 ">
						<?php echo $Form->Button('submit','btnMovirSubmit','Get Estimate Cost','',array('onclick'=>'movirApp.getEstimate();','data-loading-text'=>'Loading...')); ?>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12">
					<p class="text-center" ng-hide="price==false" >Your estimated moveing charge will be <span class="text-theme" style="font-weight: 600;"><span ng-bind="minprice"></span> TO <span ng-bind="price"></span> </span> ILS</p>
				</div>
			</div>
		</div>
		<?php echo $Form->Close(); ?>	
	</div>
</div>
<script>
/*
$(document).ready(function(){
  $('.cbx-label ').click(function(){
    $('.cbx-label ').removeClass("active");
    $(this).addClass("active");
});
});
$(document).ready(function(){
	$('.nolugging').click(function(){
		$('#floore').fadeOut('800');
		$('#floore1').fadeOut('800');
		$('.homebox').addClass("fullactive");
		});
		$('.lugging').click(function(){
		$('#floore').fadeIn('800');
		$('#floore1').fadeIn('800');
		 $('.homebox').removeClass("fullactive");
		});
	});
			$(document).ready(function(){
  $('.elevat label').click(function(){
    $('.elevat label').removeClass("active");
    jQuery(this).addClass("active");
});
});*/
</script>
<script type="text/javascript">

	function initMapDirection(){
		var directionsService = new google.maps.DirectionsService;
		var directionsDisplay = new google.maps.DirectionsRenderer;
		
		/*var map = new google.maps.Map(document.getElementById('directionMap'), {
			zoom: 1,
			center: {lat: 0, lng: 0}
		});
		directionsDisplay.setMap(map);
		
		var onChangeHandler = function() {
			calculateAndDisplayRoute(directionsService, directionsDisplay);
		};
		/*document.getElementById('start').addEventListener('change', onChangeHandler);
		document.getElementById('end').addEventListener('change', onChangeHandler);*/
		//document.getElementById('btnMapDirection').addEventListener('click', onChangeHandler);
		//document.getElementById('btnMovirSubmit').addEventListener('click', onChangeHandler);
		// Auto Complate
		var autocomplete_pickupaddress = new google.maps.places.Autocomplete(document.getElementById('pickupaddress'));
		var autocomplete_dropaddress = new google.maps.places.Autocomplete(document.getElementById('dropaddress'));
		
		
		autocomplete_pickupaddress.addListener('place_changed', function() {
			var scope = angular.element(document.getElementById('movirApp')).scope();
			place = jQuery('#pickupaddress').val();
			scope.$apply(function(){
				scope.pickAddress = place;	
			});
		});
		
		autocomplete_dropaddress.addListener('place_changed', function() {

			var scope = angular.element(document.getElementById('movirApp')).scope();
			place = jQuery('#dropaddress').val();
			scope.$apply(function(){
				scope.dropAddress = place;	
			});
		});
		
	}
	
	function calculateAndDisplayRoute(directionsService, directionsDisplay) {
		var pickup_address = document.getElementById('pickupaddress').value;
		var drop_address = document.getElementById('dropaddress').value;
		if(pickup_address == null || drop_address == null || pickup_address == '' || drop_address == ''){
			return false;	
		}
		
		directionsService.route({
			origin: pickup_address, 
			destination: drop_address, 
			travelMode: google.maps.TravelMode.DRIVING
		}, function(response, status) {
			
			if (status === google.maps.DirectionsStatus.OK) {
				directionsDisplay.setDirections(response);
			} else {
				window.alert('Directions request failed due to ' + status);
			}
		});
		return false;
		
	}

</script>

<script src="https://maps.googleapis.com/maps/api/js?signed_in=true&libraries=places&callback=initMapDirection" async defer></script>

<style type="text/css">
.map{ width:100%; min-height:256px !important; }
.control-label{ display:block; }

/* type ahead */
.typeahead, .tt-query, .tt-hint {
	border: 2px solid #CCCCCC;
	border-radius: 8px;
	font-size: 24px;
	height: 30px;
	line-height: 30px;
	outline: medium none;
	padding: 8px 12px;
	width: 396px;
}
.typeahead {
	background-color: #FFFFFF;
	height:auto;
	max-height:256px;
	overflow:auto;
}
.typeahead:focus {
	border: 2px solid #0097CF;
}
.tt-query {
	box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
}
.tt-hint {
	color: #999999;
}
.tt-dropdown-menu {
	background-color: #FFFFFF;
	border: 1px solid rgba(0, 0, 0, 0.2);
	border-radius: 8px;
	box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
	margin-top: 12px;
	padding: 8px 0;
	width: 422px;
}
.tt-suggestion {
	font-size: 24px;
	line-height: 24px;
	padding: 3px 20px;
}
.tt-suggestion.tt-is-under-cursor {
	background-color: #0097CF;
	color: #FFFFFF;
}
.tt-suggestion p {
	margin: 0;
}
/* typeahead over */


</style>
