<?php
define('DS',DIRECTORY_SEPARATOR);
define('MOVIR_BASE_PATH',dirname(dirname(dirname(__FILE__))).DS);

include(MOVIR_BASE_PATH.'lib'.DS.'class.form.php');
include(MOVIR_BASE_PATH.'lib'.DS.'helper.debug.php');