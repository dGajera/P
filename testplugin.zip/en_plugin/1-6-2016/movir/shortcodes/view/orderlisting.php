<?php

	require_once('config.php');

	$Form = new movir_form();

?>
<div class="checkloading1"></div>
<p class="text-danger " ng-bind="message[0]"></p>

<ul class="orderlisting">

	<li ng-repeat="order in orders"  >

		<ul class="list-item">

			<li><label class="label vehicletype {{ order.vehicle_class }}" ></label></li>

			<li>

				<p><label class="text-theme text-bold" ng-click="orderDetail(order.appointment_id)" style="color:#000 !important"> {{ 'OrderID' | translate }} : {{ order.appointment_id }}</label></p>

				<p><label >{{ order.driver_text }}</label></p>

				<p><label ng-bind="order.date_text"></label></p>

			</li>

			<li>

				<p><label ng-bind="order.amount_text"></label></p>

				<p><label class="label {{ order.status_class }}" > {{ order.status_text | translate }} </label></p>

				<p><a href="javascript:" class="btn btn-info btn-xs btn-block" ng-hide="!order.canreorder" ng-click="openDatechecker(order.appointment_id)" > {{ 'Reorder' | translate }}</a></label></p>

			</li> <!-- data-toggle="modal" data-target="#modalReorder"  -->

		</ul>

	</li>

</ul>

<div id="modalReorder" class="modal fade" tabindex="-1" role="dialog">

	<div class="modal-dialog">

		<div class="modal-content">

			<div class="modal-header">

				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>

				<h4 class="modal-title">{{ 'SelectDateReorder' | translate }}</h4>

			</div>

			<div class="modal-body">

				<p ng-bind="message[1]" class="text-danger text-center" style="padding:10px"></p>

				<div class="" > <!-- ng-hide="estimateCharge != false;" -->

					<?php echo $Form->Input('text','reorderappointmentdate',false,false,'',array('placeholder'=>"{{ 'AppointmentDateReorder' | translate }}",'ng-model'=>'reorder.appointmentdate'),array(),array('required'=>false)); ?>
                  <!-- <div class="col-sm-12">
								<?php //echo $Form->Input('hidden','reorderappointmentdate',false,false,'',array('placeholder'=>"{{ 'AppointmentDateReorder' | translate }}",'ng-model'=>'reorder.appointmentdate'),array(),array()); ?>
								
							</div>-->
							
							<!--<div class="col-xs-12"><p id="movir_error_step" class="text-danger error-message text-center" ng-bind="datetimeerror"></p></div>
							<div class="col-sm-12 datetime"> 
								<div class="col-sm-6 dateslot" style="direction: ltr">
										<?php echo $Form->Input('text','appointmentdate1',false,false,'',array('placeholder'=>"{{'Date'| translate}}",'ng-model'=>'order.appointmentdate1')); ?>
										<label  class="dateicon" ></label>
								</div>
								<div class="col-sm-6 timeslot">
										<?php echo $Form->Input('text','appointmenttime1',false,false,'',array('placeholder'=>"{{'Times' | translate}}",'ng-model'=>'order.appointmenttime1')); ?>
										<label  class="timeicon" ></label>
								</div>
							</div>-->

				</div>

				<div class="" ng-hide="estimateCharge == false;">

					<div class="row">

						<div class="col-xs-6 ">

							<dl class="dl-horizontal">

								<dt>{{ 'MovingCharge' | translate }}</dt>

								<dd><span ng-bind="estimateCharge.transport_charge"></span>&nbsp;<small>ILS</small></dd>

								<dt>{{ 'CouponDiscount' | translate }}</dt>

								<dd><span ng-bind="estimateCharge.discount"></span>&nbsp;<small>ILS</small></dd>

								<dt>{{ 'VAT' | translate }} (<span ng-bind="estimateCharge.vat_percentage"></span>%)</dt>

								<dd><span ng-bind="estimateCharge.vat"></span>&nbsp;<small>ILS</small></dd>

								<dt>{{ 'Total' | translate }}</dt>

								<dd><span ng-bind="estimateCharge.price"></span>&nbsp;<small>ILS</small></dd>

							</dl>

						</div>

						<div class="col-xs-12 text-center">

							<?php echo $Form->Button('button','btnAddPayment',"Add Credit Card Detail",'btn-warning',array('ng-click'=>'getCcDetailId()','data-loading-text'=>"{{ 'Loading' | translate }}")) ?>

						</div>

					</div>

				</div>

			</div>

			<div class="modal-footer">

				

				<div class="col-md-12 text-center" style="margin:0"><button id="getEstimateReorder" type="button" ng-hide="estimateCharge != false;" class="btn btn-theme btn-info" data-loading-text="{{ 'Loading' | translate }}" ng-click="getEstimate();" ng-disabled="reorder.appointmentdate == ''" >Get Estimate</button><div class="checkdateloading"></div>
                
                

				<button id="placeReorder" type="button" ng-hide="estimateCharge == false;" class="btn btn-theme btn-info" data-loading-text="{{ 'Loading' | translate }}" ng-click="placeReorder();" >Place Order</button></div>
<!--<div class="col-md-6 text-center"><button type="button" class="btn btn-default" data-dismiss="modal">Close</button></div>-->
			</div>

		</div><!-- /.modal-content -->

	</div><!-- /.modal-dialog -->

</div><!-- /.modal -->



<div id="movir_OrderPaymentModal" class="modal fade" tabindex="-1" role="dialog">

	<div class="modal-dialog">

		<div class="modal-content">

			<?php /*?><div class="modal-header"><h4 class="modal-title">Modal title</h4></div><?php */?>

			<div class="modal-body">

				<iframe id="iframeOrderPayment" class="iframeOrderPayment" src=""></iframe>

			</div>
            <div class="modal-footer" style="text-align: center !important"><button class="btn btn-warning " aria-hidden="true" data-dismiss="modal" type="button" id="modalok">OK</button></div>

		</div><!-- /.modal-content -->

	</div><!-- /.modal-dialog -->

</div><!-- /.modal -->