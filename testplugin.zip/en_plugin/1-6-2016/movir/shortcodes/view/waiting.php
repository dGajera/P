<div class="" style="margin:100px;position: relative;" ng-init="waiting_time()" >
	<!--div class='animatecontainer'>
          <div class='frame'>
            <img src='http://movir.com/wp-content/plugins/movir/src/image/imglogo1.png' />
          </div>
          <div class='frame' style="z-index:5">
            <img src='http://movir.com/wp-content/plugins/movir/src/image/imglogo2.png' />
          </div>
        </div-->
	<!--<div class="waitingimg"></div>-->
	<!--p class="text-center text-info lead" style="margin-top:10px;position:absolute;top:200px">Please wait, We are locating your nearest Personal Mover…</p-->
	<!--<div class="loding"></div>-->
	
	<div id="ajax"></div>
	
</div>
<style>
.animatecontainer {
  position: relative;
  width: 300px;
  height: 187px;
}
.frame {
  position: absolute;
  bottom: 0px;
  left: 0px;
  height: 100%;
  width: 100%;
}
.frame:nth-child(2) {
  
  height: 0px;
  overflow: hidden;
  z-index: -1;
  animation-name: fill-up;
 animation-duration: 20s;
 animation-iteration-count: infinite;
 animation-direction: normal;
 animation-timing-function: ease-out;
 animation-fill-mode: forwards;
 animation-delay: 0s;
}
.frame:nth-child(2) img {
  position: absolute;
  bottom: 0px;
}
@keyframes fill-up {
  from{
	height: 0px;
  }
  to {
    height: 187px;
  }
}

.checkmark-circle .checkmark.draw:after,.checkmark-circle .checkmark2.draw2:after{-webkit-animation-delay:.1s;-moz-animation-delay:.1s;-webkit-animation-duration:1s;-moz-animation-duration:1s;-webkit-animation-timing-function:ease;-moz-animation-timing-function:ease;-webkit-animation-name:checkmark;-webkit-animation-fill-mode:forwards;-moz-animation-fill-mode:forwards}.checkmark-circle{width:150px;height:150px;position:relative;display:inline-block;vertical-align:top}.checkmark-circle .background{width:150px;height:150px;border-radius:50%;background:#2ecc71;position:absolute}.checkmark-circle .background2{width:150px;height:150px;border-radius:50%;background:#e74c3c;position:absolute}.checkmark-circle .checkmark2:after,.checkmark-circle .checkmark3:after,.checkmark-circle .checkmark:after{opacity:1;height:75px;width:37.5px;border-right:15px solid #fff;content:'';position:absolute}.checkmark-circle .checkmark{border-radius:5px}.checkmark-circle .checkmark.draw:after{animation-delay:.1s;animation-duration:1s;animation-timing-function:ease;-moz-animation-name:checkmark;animation-name:checkmark;-webkit-transform:scaleX(-1) rotate(135deg);-moz-transform:scaleX(-1) rotate(135deg);-ms-transform:scaleX(-1) rotate(135deg);-o-transform:scaleX(-1) rotate(135deg);transform:scaleX(-1) rotate(135deg);animation-fill-mode:forwards}.checkmark-circle .checkmark:after{-webkit-transform-origin:left top;-moz-transform-origin:left top;-ms-transform-origin:left top;-o-transform-origin:left top;transform-origin:left top;border-top:15px solid #fff;border-radius:2.5px!important;left:34px;top:79px}.checkmark-circle .checkmark2{border-radius:5px}.checkmark-circle .checkmark2:after{-webkit-transform-origin:left top;-moz-transform-origin:left top;-ms-transform-origin:left top;-o-transform-origin:left top;transform-origin:left top;border-radius:2.5px!important;left:81px;top:121px}.checkmark-circle .checkmark2.draw2:after{animation-delay:.1s;animation-duration:1s;animation-timing-function:ease;-moz-animation-name:checkmark;animation-name:checkmark;-webkit-transform:scaleX(-1) rotate(228deg);-moz-transform:scaleX(-1) rotate(228deg);-ms-transform:scaleX(-1) rotate(228deg);-o-transform:scaleX(-1) rotate(228deg);transform:scaleX(-1) rotate(228deg);animation-fill-mode:forwards}.checkmark-circle .checkmark3{border-radius:5px}.checkmark-circle .checkmark3.draw3:after{-webkit-animation-delay:.1s;-moz-animation-delay:.1s;animation-delay:.1s;-webkit-animation-duration:1s;-moz-animation-duration:1s;animation-duration:1s;-webkit-animation-timing-function:ease;-moz-animation-timing-function:ease;animation-timing-function:ease;-webkit-animation-name:checkmark;-moz-animation-name:checkmark;animation-name:checkmark;-webkit-transform:scaleX(-1) rotate(135deg);-moz-transform:scaleX(-1) rotate(135deg);-ms-transform:scaleX(-1) rotate(135deg);-o-transform:scaleX(-1) rotate(135deg);transform:scaleX(-1) rotate(135deg);-webkit-animation-fill-mode:forwards;-moz-animation-fill-mode:forwards;animation-fill-mode:forwards}.checkmark-circle .checkmark3:after{-webkit-transform-origin:left top;-moz-transform-origin:left top;-ms-transform-origin:left top;-o-transform-origin:left top;transform-origin:left top;border-radius:2.5px!important;left:24px;top:79px}@-webkit-keyframes checkmark{0%{height:0;width:0;opacity:1}20%{height:0;width:37.5px;opacity:1}100%,40%{height:75px;width:37.5px;opacity:1}}@-moz-keyframes checkmark{0%{height:0;width:0;opacity:1}20%{height:0;width:37.5px;opacity:1}100%,40%{height:75px;width:37.5px;opacity:1}}@keyframes checkmark{0%{height:0;width:0;opacity:1}20%{height:0;width:37.5px;opacity:1}100%,40%{height:75px;width:37.5px;opacity:1}}



.loading-container {
  position:fixed;
  background-color:#1584A0;
  z-index:9;
  top: 0;
  left: 0;
  height:100%;
  width:100%;
  cursor:wait;
}
.timer, .timer-done, .timer-loop {
      font-size: 60px;
color: #fff;
font-weight: bold;
padding: 10px;
    }

    .hours { float: left; }
    .minutes { float: left; }
    .seconds { float: left; }
    .clearDiv { clear: both; }

    .is-complete {
      color: red;
      -webkit-animation-name: blinker;
      -webkit-animation-iteration-count: infinite;
      -webkit-animation-timing-function: cubic-bezier(1.0,0,0,1.0);
      -webkit-animation-duration: 1s;
    }
    @-webkit-keyframes blinker {
      from { opacity: 1.0; }
      to { opacity: 0.0; }
    }

</style>