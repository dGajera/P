<div class="accountdetail">
<p class="text-danger" mg-bind="message[0]"></p>

<div class="row">

	

	<div class="col-xs-4">

		<a href="{{ user.profilePic }}" target="_blank" class="thumbnail">

			<img ng-src="{{ user.profilePic }}" alt="{{ user.username }}">

		</a>

		<?php /*?><input type="file" id="profilepic" name="profilepic" ng-model="profilepic" accept="image/jpeg,image/png,image/jpg" ><?php */?>

	</div>

	<div class="col-xs-8 pull-right">

		<dl class="dl-horizontal">

			<dt>{{ 'FullName' | translate }}</dt>

			<dd><input type="text" ng-model="user.username"></dd>

			<dt>{{ 'PhoneNumber' | translate }}</dt>

			<dd><input type="tel" ng-model="user.phone" disabled></dd>

			<dt>{{ 'Emailaddress' | translate }}</dt>

			<dd><input type="email" ng-model="user.email" disabled></dd>

			<dd class="text-right"><input type="button" id="profileupdate" data-loading-text="{{ 'Loading' | translate }}" class="btn btn-theme" value="{{ 'Submit' | translate }}" ng-click="update()"></dd>

		</dl>

	</div>

</div>
</div>