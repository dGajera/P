<p class="text-danger " ng-bind="message[0]"></p>

<ul class="orderlisting">

	<li ng-repeat="invoice in invoicelist" ng-click="invoiceDetail(invoice.invoice_id)" >

		<ul class="list-item ">

			<li><label class="label logo-holder" ></label></li>

			<li>

				<p><label class="text-theme text-bold" style="color:#000"> {{ 'OrderID' | translate }} : {{ invoice.appointment_id }}</label></p>

			</li>

			<li>

				<p><label ng-bind="invoice.amount_text"></label></p>

				<p><label class="label {{ invoice.status_class }}" >{{ invoice.status_text | translate }}</label></p>

			</li>

		</ul>

	</li>

</ul>