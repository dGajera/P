<div class="allorderdetail">
<p class="text-danger" ng-bind="message[0]"></p>

<div  class="row " >

	<div class="padding-sm col-xs-12">

		<p class="text-theme text-bold text-center" style="color:#000!important;padding:10px"><label>{{ 'OrderID' | translate }} : <span ng-bind="order.appointment_id"></span></label></p>
        

		<p class="text-thin">

			<div class="col-md-5 text-center"><label class="" ng-bind="order.date_text"></label></div>

			<div class="col-md-3 text-center"><label class="label {{ order.status_class }}" >{{ order.status_text | translate }}</label></div>
            <div class="col-md-4 text-center">
          	<label ng-show="order.order_type == 1" class="label  label-success">No Lugging</label>
         	<label ng-show="order.order_type == 2" class="label  label-success">Lugging</label>
            
            </div>

		</p>

	</div>
	<div class="col-xs-12">
    <h3 class="text-center">Address Detail</h3>
	<div class="col-xs-6">

		<address>

		<strong>{{ "PickupAddress" | translate }}</strong><br>

		<span ng-bind="order.pickup_address"></span><br>
       <span ng-bind="order.pickup_phone"></span><br>

		<span ng-hide="order.order_type != 2">{{ "FloorNumber" | translate }} : <small ng-bind="order.pickup_floor" ></small>,  {{ "Elevator" | translate }}  : <small >{{ order.pickup_elevator==1?'YES':'NO' }}</small></span>

		</address>

	</div>
    

	<div class="col-xs-6">

		<address>

		<strong>{{ "DropoffAddress" | translate }}</strong><br>

		<span ng-bind="order.drop_address"></span><br>
         <span ng-bind="order.drop_phone"></span><br>

		<span ng-hide="order.order_type != 2" >{{ "FloorNumber" | translate }} : <small ng-bind="order.drop_floor"></small>,  {{ "Elevator" | translate }}  : <small>{{ order.drop_elevator==1?'YES':'NO' }}</small></span>

		</address>

	</div>
	</div>
	<div class="clear"></div>

	<hr>

	<div class="col-xs-12">
    <h3 class="text-center">Product Detail</h3>

		<table class="table">

			<tbody>

				<tr>

					<th>#</th>

					<th>{{ 'ProductName' | translate }}</th>
                    
                    <th>Image</th>

					<th ng-hide="order.order_type != 2">{{ 'Assembly' | translate }}</th>

				</tr>

				<tr ng-repeat="product in order.product_list">

					<td >{{ product.index }}</td>

					<td>{{ product.product_name }}</td>
                    
                    <td><img ng-src="{{product.image}}" width="70px"/></td>

					<td ng-hide="order.order_type != 2">{{ product.assemble==true?'YES':'NO' }}</td>

				</tr>

			</tbody>

		</table>

	</div>

	<div class="col-xs-6">
    	<h3>Price Detail</h3>

		<dl class="dl-horizontal" style="margin:0 !important">

			<dt>{{ 'MovingCharge' | translate }} : </dt>

			<dd><span ng-bind="order.transport_charge"></span>&nbsp;<small>ILS</small></dd>

			<dt>{{ 'CouponDiscount' | translate }} : </dt>

			<dd><span ng-bind="order.discount"></span>&nbsp;<small>ILS</small></dd>

			<dt>{{ 'VAT' | translate}} (<span ng-bind="order.vat_percentage"></span>%) : </dt>

			<dd><span ng-bind="order.vat"></span>&nbsp;<small>ILS</small></dd>

			<dt>{{ 'Total' | translate }} : </dt>

			<dd><span ng-bind="order.amount"></span>&nbsp;<small>ILS</small></dd>

		</dl>

	</div>
    
    <div class="driverdetail col-xs-6" ng-if="order.driver_detail">
    	<h3>Driver Detail</h3>
       
        <dl class="dl-horizontal" style="margin:0 !important">

			<dt>Name : </dt>

			<dd>
            	<span ng-bind="order.driver_detail.first_name"></span>&nbsp; &nbsp;  
                <span ng-bind="order.driver_detail.last_name"></span>
            </dd>

			<dt>Email : </dt>

			<dd><span ng-bind="order.driver_detail.email"></span></dd>

			<dt>Phone Number : </dt>

			<dd><span ng-bind="order.driver_detail.mobile"></span></dd>

			<dt>Driver Rating : </dt>

			<dd><span ng-bind="order.driver_detail.driverrating"></span></dd>
            
            <dt>Profile Pic : </dt>

			<dd><img ng-src="{{order.driver_detail.profile_pic}}" width="70px"></dd>

		</dl>
    </div>

	<div class="">

		<div class="col-sm-4 col-sm-offset-4" ng-hide="!(order.status==1 || invoice.status==2)">

			<div class="">

				<a href="javascript:" id="btnCancleOrder" data-loading-text="{{ 'Loading' | translate }}" class="btn btn-block btn-danger btn-bg" ng-click="cancleOrder()">{{ 'CanceledOrder' | translate }}</a>

			</div>

		</div>

	</div>

</div>
</div>

