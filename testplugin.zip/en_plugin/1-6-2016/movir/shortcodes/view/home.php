<?php
	require_once('config.php');
?>
<div class="col-lg-10 col-md-9 col-sm-12" style="margin:0 auto; float:none;">
	<!-- Navigation View -->
	<div ui-view="navigation" class="loginright"></div>
	<!-- Main View -->
	<div ui-view class="loginleft"><?php include('orderplace.php')?></div>
</div>
