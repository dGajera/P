<?php
	require_once('../config.php');
	$Form = new movir_Form();
?>
<div class="login-container">
	<div id="" class="col-sm-4 " style="margin:0 auto; float:none;">
	<a ui-sref="login" class="btn btn-info home-btn-login active">Login</a>
	<a ui-sref="signup" class="btn btn-info home-btn-register">Register</a>
	</div>
</div>
