<?php
	require_once('../config.php');
	$Form = new movir_Form();
?>
<div class="login-container login_form">
	<div class="col-sm-12">
		<a href="http://movir.com"><img src="http://movir.com/wp-content/plugins/movir/src/image/movirlogo.png" class="upperlogo"> </a>
	</div>
	<div class="clear"></div>
	<div id="login" class="col-sm-4 " style="">
			
		<?php echo $Form->Open('','','',array('onsubmit'=>'return false;')); ?>
			<h3 id="logintitle">{{ 'Login' | translate  }} </h3>
			<p style="color:#ccc;text-align:center">{{'ForSecurity,WeWillSendYouANewVerificationPinCode' | translate}}</p>
			<p class="text-danger" id="loginmessage"><?php echo isset($message)?$message:false;?></p>
            <div class="loginform">
			<?php
				echo $Form->Input('tel','phone',false,'','',array('placeholder'=>"{{ 'MobileNumber' | translate }}",'ng-model'=>'phone','id'=>'phone'));
				//echo '<span class="iconmo"></span>';
				echo'<span class="fa fa-mobile iconmo iconf fa-2x " aria-hidden="true"></span>';
				echo $Form->Button('submit','submit','{{ "Login" | translate }}','btn-theme btn-block',array('data-loading-text'=>"{{ 'Loading' | translate }}",'ng-click'=>'getVerificationCode()'));
				
			?>
			<div class="col-lg-12 col-md-12 col-sm-12 text-danger" ng-bind="message" style="text-align:center"></div>
            </div>
					<div class="clear"></div>
		<?php echo $Form->Close();?>
		<!-- form --> 

		<!-- content --> 
	</div>
	<div style="margin-top:10px" class="loginacount"><a class="text-theme aaccount" ui-sref="signup">{{ "DonotHaveAnAccountYet?RegisterHere" | translate }}</a></div>
</div>
<script>
jQuery("#phone").mask("999-9999999");
</script>