<?php
	require_once('../config.php');
	$Form = new movir_Form();
?>
<div class="login-container signup_form">
	<div class="col-sm-12">
		<a href="http://movir.com"><img src="http://movir.com/wp-content/plugins/movir/src/image/movirlogo.png" class="upperlogo"> </a>
	</div>
	<div class="clear"></div>
	<div id="login" class="col-sm-4 signup " style="margin:0 auto; float:none;">
		<?php echo $Form->Open('','','',array('onsubmit'=>'return false;')); ?>
			<h3 id="logintitle">{{ "AccountCreation" | translate }}</h3>
        
            <div class="formsignup">
			<p class="text-danger" id="loginmessage"><?php echo isset($message)?$message:false;?></p>
			<?php
				echo $Form->Input('text','name',false,'','',array('placeholder'=>"{{ 'FullName'  | translate}}",'ng-model'=>'name'));
					//echo '<span class="name iconf"></span>';
					echo'<span class="fa fa-user name iconf fa-lg " aria-hidden="true"></span>';
				echo $Form->Input('email','email',false,'','',array('placeholder'=>"{{ 'Emailaddress' | translate }}",'ng-model'=>'email'));
				//echo '<span class="email iconf"></span>';
				echo'<span class="fa fa-envelope-o email iconf fa-lg " aria-hidden="true"></span>';
				echo $Form->Input('tel','phone',false,'','',array('placeholder'=>"{{ 'MobileNumber' | translate }}",'ng-model'=>'phone','id'=>'phone'));
				//echo '<span class="phone iconf"></span>';
				echo'<span class="fa fa-mobile phone iconf fa-2x " aria-hidden="true"></span>';
				 ?></div>
				<div class="col-xs-12" style="" ng-hide="signupchk"><p id="" class="text-danger error-message text-center" ng-bind="chkreqmsg" style="color:#a94442 !important"></p></div>
				<div class="clear"></div>
				<div class="chk-boxe" >
					<div class="firsrche">
						<input type="checkbox" ng-model="signupchk" value="1">
						{{'IdLikeToReceiveCouponsAndInspirationalMaterial' | translate}}
					</div>
					<div class="secoderch">
						{{'Bysigningup,IAgreeToMovirs' | translate}}<a href="http://movir.com/terms-conditions-of-service/">{{'TermsAndConditions' | translate}}</a> {{'And' | translate}} <a href="http://movir.com/privacy/">{{'PrivacyPolicy' | translate}}</a>
					</div>
				</div>
	<?php
				echo $Form->Button('submit','submit','{{ "CREATE" | translate }}','btn-theme pull-right',array('data-loading-text'=>"{{ 'Loading' | translate }}",'ng-click'=>'getVerificationCode()'));
			?>
            <div class="clear"></div>
           
		<?php echo $Form->Close();?>
        
		<!-- form --> 
		<!-- content --> 
	</div>
    
     <?php
			echo '<div class="textcenter"><a class="text-theme aaccount" ui-sref="login">{{ "AlreadyHaveAnAccount?" | translate }}</a></div>';
			
			?>
</div>
<script>
jQuery("#phone").mask("999-9999999");
</script>