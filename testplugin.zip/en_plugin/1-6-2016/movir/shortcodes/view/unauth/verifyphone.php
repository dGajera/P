<?php

	require_once('../config.php');

	$Form = new movir_Form();

?>

<div class="login-container verify_form">
	<div class="col-sm-12"> 
		<a href="http://movir.com"><img src="http://movir.com/wp-content/plugins/movir/src/image/movirlogo.png" class="upperlogo"> </a>
	</div>
	<div class="clear"></div>

	<div id="login" class="col-sm-4 verify " style="margin:0 auto; float:none;">

		<?php echo $Form->Open('','','',array('onsubmit'=>'return false;')); ?>

			<h3 id="logintitle">{{ 'VerifyandLogin' | translate }} </h3>

			<p class="text-danger" id="loginmessage"><?php echo isset($message)?$message:false;?></p>

			<?php

				echo $Form->Input('text','code',false,'','',array('placeholder'=>"{{ 'Code' | translate }}",'ng-model'=>'code'));

				

				echo $Form->Button('submit','submit','{{ "VERIFY" | translate }}','btn-theme pull-right',array('data-loading-text'=>"{{ 'Loading' | translate }}",'ng-click'=>'submit()'));
	
			?>
			<div class="col-lg-12 col-md-12 col-sm-12 text-danger" ng-bind="message" style="text-align:center"></div>
			<div class="clear"></div>
		<?php echo $Form->Close();?>
        

		<!-- form --> 

		<!-- content --> 

	</div>
    <div class="clear"></div>
        <?php
		echo '<div class="textcenter"><a class="text-theme aaccount" ui-sref="login">{{ "DidnotReceiveTheVerificationCode?ClickHere" | translate }}</a></div>';
		
		?>

</div>

