<?php
add_action('init',function(){ add_shortcode('movir_order','movir_webapplication_init'); });


if(! function_exists('movir_webapplication_init')):
	
	function movir_webapplication_init($args){
		wp_enqueue_script('jquery');
		
		wp_register_script( 'movir_bootstap_js',MOVIR_URL.'src/js/bootstrap.min.js',array('jquery'));
		wp_enqueue_script( 'movir_bootstap_js');
		
		wp_register_script('movir_angular',MOVIR_URL.'src/js/angular.min.js',array(),'',false);
		wp_enqueue_script('movir_angular');
		
		wp_register_script('movir_moment','http://momentjs.com/downloads/moment.js',array(),'',false);
		wp_enqueue_script('movir_moment');
		
		wp_register_script('movir_angular_ui_route',MOVIR_URL.'src/vendor/angular/angular-ui-router.min.js',array(),'',false);
		wp_enqueue_script('movir_angular_ui_route');
		
		wp_register_script('movir_helper',MOVIR_URL.'src/js/helper.js',array(),'',false);
		wp_enqueue_script('movir_helper');
		
		wp_register_script('movir_angular_bootstrap',MOVIR_URL.'src/vendor/bootstrap/js/ui-bootstrap-tpls-0.12.1.min.js',array(),'',false);
		wp_enqueue_script('movir_angular_bootstrap');
		

		//wp_register_script('movir_custom',MOVIR_URL.'src/js/custom.js',array('jquery'));
		//wp_enqueue_script('movir_custom');
		
		wp_register_script('angular-animate',MOVIR_URL.'src/js/angular-animate.js',array('jquery'));
		wp_enqueue_script('angular-animate');
		
		wp_register_script('angular-ui-bootstrap',MOVIR_URL.'src/js/angular-ui-bootstrap.js',array('jquery'));
		wp_enqueue_script('angular-ui-bootstrap');
		
		//wp_register_script('movir_datetime-picker',MOVIR_URL.'src/js/datetime-picker.js',array('angular-ui-bootstrap'),'',false);
		//wp_enqueue_script('movir_datetime-picker');
		
		wp_register_script('movir_datetime-picker','//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/src/js/bootstrap-datetimepicker.js',array('angular-ui-bootstrap'),'',false);
		wp_enqueue_script('movir_datetime-picker');
		
		wp_register_script('movir-typeahead',MOVIR_URL.'src/plugin/typeahead/bootstrap-typeahead.min.js',array('jquery'));
		wp_enqueue_script('movir-typeahead');
		
		//wp_register_script('movir-tab',MOVIR_URL.'src/plugin/tabs/tabs.js',array('jquery'));
		//wp_enqueue_script('movir-tab');
		
		wp_register_script('movir-progressbar',MOVIR_URL.'src/plugin/progressbar/progressbar.js',array('jquery'));
		wp_enqueue_script('movir-progressbar');
		
		//	Translator
		wp_register_script('movir-angular-translate',MOVIR_URL.'src/vendor/angulartranslate/angular-translate.min.js',array('movir_angular'));
		wp_enqueue_script('movir-angular-translate');
		
		
		
		
		
		wp_register_script('movir-angular-translate-loader-static-files',MOVIR_URL.'src/vendor/angulartranslate/angular-translate-loader-static-files.min.js',array('movir_angular'));
	//	wp_enqueue_script('movir-angular-translate-loader-static-files');
		
		wp_register_script('movir-translate-storage-local',MOVIR_URL.'src/vendor/angulartranslate/angular-translate-storage-local.min.js',array('movir_angular'));
	//	wp_enqueue_script('movir-translate-storage-local');
		
		wp_register_script('movir-translate-storage-cookie',MOVIR_URL.'src/vendor/angulartranslate/angular-translate-storage-cookie.min.js',array('movir_angular'));
	//	wp_enqueue_script('movir-translate-storage-cookie');
		
		
		//	Map
		wp_register_script('movir_google_map', 'https://maps.googleapis.com/maps/api/js?signed_in=true&libraries=places&callback=initMap',array('jquery','movir_angular','movir_helper'));
		wp_enqueue_script('movir_google_map');
		
		//	Application js
		wp_register_script('movir_app_config',MOVIR_URL.'src/js/config.js',array('jquery','movir_angular'));
		wp_enqueue_script('movir_app_config');
		
		wp_register_script('movir_app_config_translator',MOVIR_URL.'src/js/config.translator.js',array('jquery','movir_app_config'));
		wp_enqueue_script('movir_app_config_translator');
		wp_register_script('movir-angular-countdown',MOVIR_URL.'src/js/jquery.simple.timer.js',array('jquery'));
		wp_enqueue_script('movir-angular-countdown');
		
		
		wp_register_script('movir_app',MOVIR_URL.'src/js/app.js',array('jquery','movir_angular','movir_app_config'));
		wp_enqueue_script('movir_app');
		
		wp_register_script('movir_app_mask',MOVIR_URL.'src/js/jquery.maskedinput-1.3.min.js',array('jquery'));
		wp_enqueue_script('movir_app_mask');
		
		wp_register_script('movir_file_upload',MOVIR_URL.'src/js/bootstrap-fileinput.js',array('jquery'));
		wp_enqueue_script('movir_file_upload');
		
		wp_register_script('movir_file_uploadd',MOVIR_URL.'src/js/angular-file-upload.js',array('jquery'));
		wp_enqueue_script('movir_file_uploadd');
		
		//wp_register_script('movir_file_crop',MOVIR_URL.'src/js/ng-img-crop.js',array('jquery'));
		//wp_enqueue_script('movir_file_crop');
		
		
		
		wp_register_script('movir-angular-cookie',MOVIR_URL.'src/js/angular-cookies.js',array('jquery'));
		wp_enqueue_script('movir-angular-cookie');
		
		
		// style
		wp_enqueue_style('movir_style1', MOVIR_URL.'src/css/bootstrap.min.css',array(), '1.0','screen');
		wp_enqueue_style('movir_style3', '//cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/build/css/bootstrap-datetimepicker.css',array(), '1.0','screen');
		wp_enqueue_style('movir_style', MOVIR_URL.'src/css/style.css',array(), '1.0','screen');
		//wp_enqueue_style('movir_image_crop', MOVIR_URL.'src/css/ng-img-crop.css',array(), '1.0','screen');
		
		
		wp_enqueue_style('movir_style_2', MOVIR_URL.'src/css/bootstrap-fileinput.css',array(), '1.0','screen');
		
		
		ob_start();
		include(MOVIR_PATH.'shortcodes/view/index.php');
		$content = ob_get_contents();
		ob_end_clean();
		$content = str_replace('	','',$content);
		return $content;
	}

endif;




//	Movir API call function 
add_action( 'wp_ajax_nopriv_movir_callapi', 'movir_callapi' );
add_action( 'wp_ajax_movir_callapi', 'movir_callapi' );
function movir_callapi(){
	$response = array();
	header('Content-type: application/json');
	$post = $_POST;
	$action = isset($post['api_action'])?$post['api_action']:false;
	if(! $action){
		die(json_encode(array('status'=>400,'message'=>'Invalid Request')));
	}
	
	$url = rtrim(MOVIR_API_URL,'/').'/'.$action;
	$headers = array("Content-Type: application/x-www-form-urlencoded","access-control-allow-origin: *");
	$request = array();
	$request = isset($post['data'])&&is_array($post['data'])?http_build_query($post['data']):false;
	
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
	curl_setopt($ch,CURLOPT_POST,1);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$request);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
	$response = curl_exec($ch);
	curl_close($ch);
	die($response);
	return false;
}


//	session save function 
add_action( 'wp_ajax_nopriv_movir_savesession', 'movir_savesession' );
add_action( 'wp_ajax_movir_savesession', 'movir_savesession' );

function movir_savesession(){
	$data = isset($_REQUEST['data'])?$_REQUEST['data']:false;
	if($data){
		$_SESSION = $data;
		
	}
	header('Content-type: application/json');
	die(json_encode(array('status'=>200,'message'=>'ok')));
}
add_action( 'wp_ajax_nopriv_movir_deletesession', 'movir_deletesession' );
add_action( 'wp_ajax_movir_deletesession', 'movir_deletesession' );

function movir_deletesession(){
	$data = isset($_REQUEST['data'])?$_REQUEST['data']:false;
	if($data){
		$_SESSION = $data;
		session_destroy();
		
	}
	header('Content-type: application/json');
	die(json_encode(array('status'=>200,'message'=>'ok')));
}
