// JavaScript Document
/******************************************************************************************************************************************************************/
// Order page (Estimate Page)
window.onload = function(){
	document.getElementById('movirAppCtrl').style.visibility = 'visible';
}
jQuery(document).ready(function(e) {
	scope = angular.element(document.getElementById('movirAppCtrl')).scope();
	scope.$apply(function(){
		scope.init();
	});
});

angular.module('movir',[])
	.controller('movirEstimateController',['$scope',function($scope){
		$scope.ordertype = 0;
		$scope.pickAddress;
		$scope.dropAddress;
		$scope.pickFloor = '';
		$scope.dropFloor = '';
		$scope.isValidAddress = false;
		$scope.price = false;
		$scope.minprice = false;
		// init function 
		$scope.init = function(){
			$scope.setOrderType(1);
		};
	
		// Set Order Type
		$scope.setOrderType = function(val){
			var value = val.ordertype;
			if(typeof(val) == 'number' ){
				value = val;
			}
			jQuery('.ordertype-list .cbx-label','#movirAppCtrl').removeClass('active');
			jQuery('.ordertype-list .cbx-label input[value="'+value+'"]','#movirAppCtrl').parent('.cbx-label').addClass('active');
			$scope.ordertype = value;
		};
		$scope.pickupaddress_blur = function(e){
			//$scope.setPickupAddress(e.pickAddress);
			movirApp.validateCity();
		};
		
		$scope.setEstimateCharge = function(charges){
			if(! charges){ 
				$scope.minprice = false;
				$scope.price = false; 
				return false;
			}
			$scope.minprice = charges.minprice;
			$scope.price = charges.maxprice;
			return true;
		}
	}]);
/*** ANgular Js Close ***/

var movirApp = movirApp || {};
movirApp = {
	//movirAppScope : angular.element(document.getElementById('movirAppCtrl')).scope(),
	
	validateCity: function(){
		var btn = jQuery('#btnMapDirection','#movirAppCtrl').button('loading');
		var geocoder = new google.maps.Geocoder();
		var address = document.getElementById('pickupaddress').value;
		var dropaddress = document.getElementById('pickupaddress').value;
		if(address==null || address=='' || dropaddress==null || dropaddress==''){
			jQuery(btn).button('reset');
			//alert('Please Enter Address');
			return false;	
		}
		geocoder.geocode( { 'address': address}, function(results, status) {
		
			if (status == google.maps.GeocoderStatus.OK) {
				var latitude = results[0].geometry.location.lat();
				var longitude = results[0].geometry.location.lng();
				var data = new Object();
				data.userid = user.userid;
				data.token = user.token;
				data.latitude = latitude;
				data.longitude = longitude;
				
				var parent_object = jQuery('#pickupaddress','#movirAppCtrl').parent('.form-group');
				var error_container = jQuery('#movir_error_step_2','#movirAppCtrl');
				jQuery(parent_object).removeClass('has-error');
				jQuery(error_container).html('');
				movir_callApi('validateCountry',data,function(payload){
					var flag = true;
					if(payload.errFlag == 1){
						alert(payload.errMsg);
						flag = false;
					}
					jQuery(btn).button('reset');
					scope = angular.element(document.getElementById('movirAppCtrl')).scope();
					scope.$apply(function(){
						scope.isValidAddress = flag;
					})
				})
			} 
		}); 
	},
	
	getEstimate : function(){
		var btn = jQuery('#btnMovirSubmit','#movirAppCtrl').button('loading');		
		scope = angular.element(document.getElementById('movirAppCtrl')).scope();
		if(! scope.isValidAddress){ 
			alert('Please Enter Valid Address'); 
			jQuery(btn).button('reset'); 
			return false; 
		}
		var request = new Object();
		scope.$apply(function(){
			scope.setEstimateCharge(false);	
		});
		request.userid = user.userid;
		request.token = user.token;
		
		request.ordertype = scope.ordertype;
		request.pickupaddress = scope.pickAddress;
		request.dropaddress = scope.dropAddress;

		/*request.products = '';
		for(i in scope.product){
			if(request.products == ''){
				request.products +=  i;
			}else{
				request.products +=  ','+i;
			}
		}
		*/
		if(scope.ordertype == 2){
			request.pickupfloor = scope.pickFloor;
			request.dropfloor = scope.dropFloor;
		}
		
		movir_callApi('webgetestimate',request,function(data){
			jQuery(btn).button('reset');
			if(data.errFlag != 0){ alert(data.errMsg); return false; }
			var charges = data.data;
			/*scope = angular.element(document.getElementById('movirAppCtrl')).scope();*/
			
			scope.$apply(function(){
				scope.setEstimateCharge(charges);	
			})
		});
	},
	
}	

/******************************************************************************************************************************************************************/
function movir_callApi(api_action,data,callback){
	jQuery.ajax({
		url: ajaxurl,
		type:'POST',
		data:{
			'action':	'movir_callapi',
			'api_action':api_action,
			'data':data
		},
		success: function(data,status,xhr){
			callback(data);
		},
		error: function (xhr,status,error){
			alert(status);
			jQuery('#btnMovirSubmit','#movirAppCtrl').button('reset');
		}
	});
}


// Helper Function 
function getQueryString(obj) {
	var str = [];
	for(var p in obj){
		if (obj.hasOwnProperty(p)) {
			str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
		}
	}
	return str.join("&");
}
