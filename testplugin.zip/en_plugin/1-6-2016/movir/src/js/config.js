// JavaScript Document
angular.module('movirmoduler',[
	'ui.router',
	'ngAnimate',
	'ui.bootstrap',
	'pascalprecht.translate',
	'angularFileUpload',
	'ngCookies'
	

]);
var movirapp = angular.module('movirApp',['movirmoduler']);

//	Route
movirapp.config(['$translateProvider','$stateProvider', '$urlRouterProvider','$translateProvider',
	function ($translateProvider,$stateProvider, $urlRouterProvider,$translateProvider) {
		//	Default Language
		
		$translateProvider.preferredLanguage(default_language);
		console.log(window.location.search);
		if(window.location.search=="?path=signup"){
			//alert(1);
			$urlRouterProvider.otherwise("signup");
		}else{
			$urlRouterProvider.otherwise("login");
		}
		$stateProvider.state('login',{
			url : '/login',
			templateUrl : view_path+'unauth/login.php',
			controller: 'ctrlLogin'
		}).state('signup',{
			url : '/signup',
			templateUrl : view_path+'unauth/signup.php',
			controller: 'ctrlSignup'
		}).state('verify',{
			url : '/verify',
			templateUrl : view_path+'unauth/verifyphone.php',
			controller: 'ctrlVerify'
		}).state('useroption',{
			url : '/useroption',
			templateUrl : view_path+'unauth/useroption.php',
			//controller: 'ctrlVerify'
		})
		//	Application Route
		.state('app',{
			url : '/home',
			views: {
				'' : { 
					templateUrl : view_path+'home.php',
					controller: 'ctrlOrderplace',
				 },
				'navigation@app' : { 
					templateUrl : view_path+'navigation.php',
					controller : 'ctrlNavigation'
				}
			}
		}).state('app.orderplace',{
			url:'/orderplace',
			templateUrl : view_path+'orderplace.php',
			controller : 'ctrlOrderplace',
		}).state('app.waiting',{
			url:'/waiting',
			templateUrl:view_path+'waiting.php'
		})
		//	Live track Routing
		.state('app.track',{
			url:'/track',
			templateUrl:view_path+'livetrack.php',
			controller:'ctrlLivetrack'
		})
		//	Order Routing 
		.state('app.orderhistory',{
			url:'/order/history',
			templateUrl:view_path+'orderlisting.php',
			controller:'ctrlOrderhistory'
		}).state('app.orderdetail',{
			url:'/order/detail/:orderid',
			templateUrl:view_path+'orderdetail.php',
			controller:'ctrlOrderdetail'
		})
		//	Invoice Routing
		.state('app.invoice',{
			url:'/invoice',
			templateUrl:view_path+'invoicelisting.php',
			controller:'ctrlInvoice'
		}).state('app.invoicedetail',{
			url:'/invoice/detail/:invoiceid',
			templateUrl:view_path+'invoicedetail.php',
			controller:'ctrlInvoicedetail'
		})
		//	Driver Rating 
		.state('app.rating',{
			url:'/rating/:appointmentid',
			templateUrl:view_path+'rating.php',
			controller:'ctrlRating'
		})
		//	Extra Routing 
		.state('app.account',{
			url:'/account',
			templateUrl:view_path+'account.php',
			controller:'ctrlAccount'
		}).state('app.support',{
			url:'/support',
			templateUrl:view_path+'support.php',
			//controller:'ctrlSupport'
		}).state('app.logout',{
			url:'/logout',
			controller:'ctrlLogout'
		});
		
		
		
}]);


movirapp.run(['$http','$rootScope','$state', '$stateParams','websocket',
	function ($http,$rootScope, $state, $stateParams,websocket) {
		$rootScope.websocket = websocket; 
		
		$rootScope.$state = $state;
		$rootScope.$stateParams = $stateParams;
		$rootScope.devicetype = 3; // Device type 3 for `Web Application`
		$rootScope.websocket = new Object();
		//	Session management
		$rootScope.sessionid = session_id;
		$rootScope.session = new Object();
		//	language
		$rootScope.session.language = default_language;
		
		if(typeof(session.user) == 'object' && typeof(session.user.token) == 'string'){
			$rootScope.session = session;
		}
		
		// Session save function 
		$rootScope.saveSession = function(){
			var request = new Object();
			request.action = 'movir_savesession'	
			request.data = $rootScope.session;
			$http({
				url:ajaxurl,
				method:'POST',
				headers: {'Content-Type': 'application/x-www-form-urlencoded'},
				transformRequest: function(obj) {
					return getQueryString(obj);
				},
				data:request,
			}).success(function(data, status){ session = $rootScope.session;});
		}// sessionsave Over
		$rootScope.deleteSession = function(){
			var request = new Object();
			request.action = 'movir_deletesession'	
			request.data = $rootScope.session;
			$http({
				url:ajaxurl,
				method:'POST',
				headers: {'Content-Type': 'application/x-www-form-urlencoded'},
				transformRequest: function(obj) {
					return getQueryString(obj);
				},
				data:request,
			}).success(function(data, status){ session = $rootScope.session;});
		}// sessionsave Over
		
		// Call Api Function
		$rootScope.callApi = function (api,param,callback){
			var request = new Object();
			request.action = 'movir_callapi';
			request.api_action = api;
			param.lang = $rootScope.session.language;
			request.data = param;
			$http({
				url:ajaxurl,
				method:'POST',
				headers: {'Content-Type': 'application/x-www-form-urlencoded'},
				transformRequest: function(obj) {
					return getQueryString(obj);
				},
				data:request,
			}).success(function(data, status){
				if(data.errNum == 7){
					$rootScope.session = new Object();
					$rootScope.saveSession();
					$state.go('login');
					return false;	
				}
				if(typeof(callback) == 'function'){ 
					callback(data, status); 
				}
			});
		} // Call Api function Over
		
		
		//	Application statemaintainer function
		$rootScope.checkSession = function(){
			var session = $rootScope.session;
			if(typeof(session.user) != 'object' || typeof(session.user.token) != 'string' ){
				$state.go('login');
				return false;
			}
			return true;
		}
		
		//	Init function
		$rootScope.init = function(){
			
			if(! $rootScope.checkSession()){
				return false;	
			}
			//	Connect socket to server
			//websocket.init(socket_url);
			
			//	check for current appointment
			var action = 'waitingorder';
			var request = new Object();
			request.userid = $rootScope.session.user.userid;
			request.token = $rootScope.session.user.token;
			$rootScope.callApi(action,request,function(payload){
				console.log(payload);
				if(payload.errFlag == 0){ 
					$state.go('app.waiting');	
					return ; 
				}else if(payload.errFlag == 1){
					$state.go('app');
				}
			});
		}
		$rootScope.init();
		
}]);


//	services
movirapp.factory('websocket',['$rootScope','$state',function($rootScope,$state){
	var websocket = new Object(); 
	var notification = new Object();
	
	desktopNotification = function(title,desription) {
		var icon = plugin_url+"src/image/app_icon.png";
		var direction = 'ltr';
		
		if($rootScope.language == 'hw'){
			direction = 'rtl';
		}
		// Let's check if the browser supports notifications
		if (!("Notification" in window)) {
			alert("This browser does not support desktop notification");
		}else if (Notification.permission === "granted") {	// Let's check if the user is okay to get some notification
			// If it's okay let's create a notification
			var options = {
				body: desription,
				icon: icon,
				dir : "ltr"
			};
			var notification = new Notification(title,options);
		}
		// Otherwise, we need to ask the user for permission
		// Note, Chrome does not implement the permission static property
		// So we have to check for NOT 'denied' instead of 'default'
		else if (Notification.permission !== 'denied') {
			Notification.requestPermission(function (permission) {
				// Whatever the user answers, we make sure we store the information
				if (!('permission' in Notification)) {
					Notification.permission = permission;
				}
				
				// If the user is okay, let's create a notification
				if (permission === "granted") {
					var options = {
						body: desription,
						icon: icon,
						dir : "ltr"
					};
					var notification = new Notification(title,options);
				}
			});
		}
		// At last, if the user already denied any notification, and you
		// want to be respectful there is no need to bother them any more.
		return notification;
	}
	
	websocket.init = function(socket_url){
		websocket = new WebSocket(socket_url);
		websocket.onopen = function(env){
			console.log('connected'); 
			var msg = {'session':session_id};
			websocket.send(JSON.stringify(msg));
			isConnected = true;
		}
		websocket.onerror = function(env){
			console.log('onerror'); 
		}
		websocket.onclose = function(env){ 
			console.log('onclose'); 
			setTimeout(websocket.init(socket_url),3000);
		}
		
		websocket.onmessage = function(env){
			var data = env.data;
			data = JSON.parse(data);
			console.log(data);
			if(data.status != 200){ console.log('Push notification error : '.data.message); return false; }
			var data = data.payload;
			var notification = desktopNotification('Movir Notification',data.message);
			
			switch(data.status){
				case 200:
						$state.go('app.track');
						notification.onclick = function(){	$state.go('app.track');	}
					break;
				case 201:
						$state.go('app.orderdetail',{'orderid':data.appointmentid});
						break;
				case 203:
						$state.go('app.orderdetail',{'orderid':data.appointmentid});
						notification.onclick = function(){	$state.go('app.orderdetail',{'orderid':data.appointmentid});	}
					break;
				case 204:
						$state.go('app');
						notification.onclick = function(){	$state.go('app');	}
					break;
			}
		}	
		return websocket;
	}
	return websocket;
}])
