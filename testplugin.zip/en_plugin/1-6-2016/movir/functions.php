<?php
if(! function_exists('movir_getBaseurl')):
	function movir_getBaseurl(){
		return 	rtrim(MOVIR_URL.MOVIR_INDEX,'/').'/';
	}
endif;

/*if(!function_exists('movir_getUrlSegment')):
	function movir_getUrlSegment($base_url,$segment = FALSE){
		$result = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		//$result = str_replace(INDEX,'',$result);
		$result = substr($result,strlen($base_url));
		$result = trim($result,'/');
		if(is_numeric($segment) ):
			$segments = explode('/',$result);
			return $segments[$segment];
		endif;
		return  $result;
	}
endif;*/
