// JavaScript Document

//	Main Application Controller
movirapp.controller('movirAppCtrl',['$http','$rootScope', '$scope', '$state',  '$window', '$document', '$timeout', '$translate','$cookies' ,
function ($http, $rootScope, $scope, $state,  $window, $document, $timeout,$translate,$cookies) {
	//	Call Api function Over
	$rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {});
	$rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
	});
	
	$rootScope.language = {
		// Handles language dropdown
		listIsOpen: false,
		// list of available languages
		available: {
			'en': 'English',
			'hw': 'Hebrew',
		},
		// display always the current ui language
		init: function () {
			var proposedLanguage = $translate.proposedLanguage() || $translate.use();
			var preferredLanguage = $translate.preferredLanguage();
			// we know we have set a preferred one in app.config
			$rootScope.language.selected = $rootScope.language.available[(proposedLanguage || preferredLanguage)];
		},
		set: function (localeId, ev) {
			console.log(localeId);
			console.log($translate.use(localeId));
			$rootScope.language.selected = $rootScope.language.available[localeId];
			$rootScope.language.listIsOpen = !$rootScope.language.listIsOpen;
		}
		
	};
	$rootScope.$on('$translateChangeSuccess', function () {
		//$translate.refresh();
	});
	$rootScope.language.init();
	 $(document).ready( function() {
        $.getJSON("http://freegeoip.net/json/", function(result){
            //alert('Country: ' + result.country_name + '\n' + 'Code: ' + result.country_code);
			var countrycode = result.country_code;
			if(countrycode == "IN"){
				$scope.concode = 91; //test
				//$scope.subphonecode = 2;
			}else if(countrycode == "IL"){
				$scope.concode = 972; //test
				//$scope.subphonecode = 3
			}
            
        });
    }); 
}]);

//	Login controller
movirapp.controller('ctrlLogin',['$rootScope', '$scope', '$state',
	function($rootScope, $scope, $state){
		$scope.init = function(){
			//	Maintain state of application
			var session = $rootScope.session;
			if(typeof(session.user) != 'undefined' && typeof(session.user.token) != 'undefined'){
				$state.go('app');
			}/*else if(! isNaN($rootScope.session.verificationcode)){
				//	If verification code exists then send to `Verification screen`
				$state.go('verify');
			}*/
		}
		$scope.init(); 
				
		$scope.getVerificationCode = function(){
			var action = 'customerLogin';
			var data = new Object();
			
			data.phone = $scope.concode+$scope.phone.replace(/-/g, "");
			data.country = $scope.concode;
			var button = jQuery('#submit','#movirAppCtrl').button('loading');
			$rootScope.callApi(action,data,function(data){
				jQuery(button).button('reset');
				if(data.errFlag != 0){ $rootScope.message = data.errMsg; return false; }
				data = data.data;
				$rootScope.session.user = new Object();
				$rootScope.session.user.userid = data.userid;
				$rootScope.session.verificationcode = data.verificationcode;
				$rootScope.saveSession();
				$state.go('verify');
			});
			return false;
		}
}]);	// Login Controller Over 


//	Logout controller
movirapp.controller('ctrlLogout',['$rootScope', '$scope', '$state','$window',
	function($rootScope, $scope, $state ,$window){	
		var session = $rootScope.session;
		//alert(typeof(session.user));
		if(typeof(session.user) == 'undefined'){
			$window.location.href = home_url;
		}else{
				var action = 'webuserlogout';
				var data = new Object();
				data.usertype = 2;
				data.userid = session.user.userid;
				data.token = session.user.token;
				
				//console.log(data);
				$rootScope.callApi(action,data,function(data){
						//console.log(data);
						if(data.errNum == 29){
							$rootScope.deleteSession();
							$window.location.href = home_url;	
						}else{
							$rootScope.deleteSession();
							$state.go('login');
						}
					});
			}
		//console.log(session);
		
			return false;
		
}]);	// Logout Controller Over  

// Signup Controller
movirapp.controller('ctrlSignup',['$rootScope', '$scope', '$state',
	function($rootScope, $scope, $state){
		
		$scope.init = function(){
			//	Maintain state of application
			var session = $rootScope.session;
			//console.log(session);
			if(typeof(session.user) != 'undefined' && typeof(session.user.token) != 'undefined'){
				$state.go('app');
			}/*else if(! isNaN($rootScope.session.verificationcode)){
				//	If verification code exists then send to `Verification screen`
				$state.go('verify');
			}*/
		}
		$scope.init();
		
		$scope.getVerificationCode = function(){
			var action = 'customerSignup';
			var data = new Object();
			data.name = $scope.name
			data.email = $scope.email;
			data.phone = $scope.concode+$scope.phone.replace(/-/g, "");
			data.country = $scope.country;
			data.ent_device_type = $rootScope.devicetype ; // 
			if($scope.signupchk == true){
				data.is_subscribed = 1;	
				//alert(data.isSubscribed);
			}else{
				data.is_subscribed = 0;	
				//alert(data.isSubscribed);
			}
			
			var button = jQuery('#submit','#movirAppCtrl').button('loading');
			$rootScope.callApi(action,data,function(data){
				jQuery(button).button('reset');
				if(data.errFlag != 0){ $rootScope.message = data.errMsg; return false; }
				data = data.data;
				$rootScope.session.user = new Object()
				$rootScope.session.user.userid = data.userid;
				$rootScope.session.verificationcode = data.verificationcode;
				$rootScope.saveSession();
				$state.go('verify');
				
			});
			return false;
		}
}]);	// Signup Controller Over 

//	Verification Controller
movirapp.controller('ctrlVerify',['$rootScope','$scope','$state',
	function($rootScope,$scope,$state){
		$scope.init = function(){
			//	If verification code NOT exists then send to `Login screen`
			/*if(isNaN($rootScope.session.verificationcode)){
				$state.go('login');
			}*/
					
		}
		$scope.init();
		
		$scope.submit = function(){
			if($rootScope.session.verificationcode != $scope.code){	
				$rootScope.message = 'Invalid code has submited ! Please try again';
				return false;
			}
			$rootScope.message  = '';
			var action = 'verifycustomer';
			var data = new Object();
			data.userid = $rootScope.session.user.userid;
			data.ent_dev_id = 'web application';
			data.ent_device_type = $rootScope.devicetype ; // 
			data.ent_push_token = $rootScope.sessionid;
			 
			var button = jQuery('#submit','#movirAppCtrl').button('loading');
			$rootScope.callApi(action,data,function(data,status){
				jQuery(button).button('reset');
				if(data.errFlag != 0){ $rootScope.message = data.errMsg; return false; }
				//data = data.data;
				var user = new Object();
				user = data;
				delete user.errFlag;
				delete user.errMsg;
				delete user.errNum;
				delete user.flag;
				$rootScope.session.user = user;
				$rootScope.session.verificationcode = false;
				$rootScope.saveSession();
				
				//	Start Socket
				$rootScope.init();
				
			});
		}
		
	}
	
]);	//	Verification controller Over

//	navigation Controller (Maintain Top navigation system)
movirapp.controller('ctrlNavigation',['$scope',function($scope){
	$scope.navigation = new Object();
	$scope.navigation.home 			= {'text':'Home','href':'app','class':'home'};
	$scope.navigation.track 		= {'text':'LiveTracking','href':'app.track','class':'orderhistory'};
	$scope.navigation.orderhistory 	= {'text':'OrderHistory','href':'app.orderhistory','class':'orderhistory'};
	$scope.navigation.invoice 		= {'text':'Invoice','href':'app.invoice','class':'invoice'};
	$scope.navigation.account 		= {'text':'Account','href':'app.account','class':'account'};
	$scope.navigation.support 		= {'text':'Support','href':'app.support','class':'support'};
	$scope.navigation.logout 		= {'text':'Logout','href':'app.logout','class':'logout'};
	
	//$scope.navigation.orderplace	= {'text':'Place Order',href:'app'};
}]);	//	Navigation Controller

//	After Auth Application Controller (Also Order Place Controller )
movirapp.controller('ctrlOrderplace',['$rootScope','$scope','$state','$window','$upload','$cookies',
	function($rootScope, $scope,$state,$window,$upload,$cookies){
		var img_path = '';
		// Resource
		  /*var action = 'webgetSlaveCurrentAppointment';
			var request = new Object();
			request.userid = $rootScope.session.user.userid;
			
			$rootScope.callApi(action,request,function(payload){
				console.log(payload);
				if(payload.errFlag == 0){ 
					console.log('no');
					$state.go('app.track');	
					return false;
					
					return ; 
				}else if(payload.errFlag == 1){
					//$state.go('app');
					console.log('yes');
				}
			});*/
			
		$scope.resource = new Object();
		//	Order type
		$scope.resource.ordertype = new Object();
		$scope.resource.ordertype[0] = {'text':'DoItYourself','value':1};
		$scope.resource.ordertype[1] = {'text':'HireAPro',	'value':2};
		
		//	Vehicle type
		$scope.resource.vehicletype = new Object();
		$scope.resource.vehicletype[1] = {'text':'Minivan',	'value':1};
		$scope.resource.vehicletype[2] = {'text':'PickupTruck','value':2};
		$scope.resource.vehicletype[3] = {'text':'Truck','value':3};
		//$scope.resource.vehicletype[4] = {'text':'Motorcycle','value':4};
		//$scope.resource.vehicletype[5] = {'text':'Sedan','value':5};
		
		// Order 
		$scope.order = new Object();
		$scope.order.ordertype = 1;
		$scope.order.vehicletype = 1;
		$scope.order.pickAddress;
		$scope.order.dropAddress;
		$scope.order.city = false;
		$scope.order.dropcity = false;
		$scope.order.zipcode = false;
		$scope.order.dropzipcode = false;
		$scope.order.pickFloor = null;
		$scope.order.dropFloor = null;
		$scope.order.pickupElevator = 0;
		$scope.order.dropElevator = 0;
		$scope.order.isAssembly = 0;
		$scope.order.product = new Object();
		$scope.order.assembleProduct = new Object();
		$scope.order.price = new Object();
		$scope.order.estimateCharge = false;
		//$scope.order.appointmentdate = false;
		$scope.order.ccdetailid = false;
		$scope.couponverified = false;
		// Accordiant
		$scope.oneAtATime = true;
		$scope.complatedStep = 1;
		$scope.openStep = 1;
		//console.log($rootScope.session);
		if(typeof(session.user) != 'undefined' && typeof(session.user.phone) != 'undefined'){
			var data = new Object();
			if($scope.concode == 91){
				$scope.subphonecode = 2;
				data.phone = $rootScope.session.user.phone.substring($scope.subphonecode);
				data.phone1 =data.phone.slice(0,3)+"-"+data.phone.slice(3,10);
				$scope.order.pickupphone = data.phone1;
			}else if($scope.concode == 972){
				$scope.subphonecode = 3;
				data.phone = $rootScope.session.user.phone.substring($scope.subphonecode);
				if(data.phone.length == 9){
					data.phone2 = "0"+data.phone;
				}else{
					data.phone2 = data.phone;	
				}
				data.phone1 =data.phone2.slice(0,3)+"-"+data.phone2.slice(3,10);
				$scope.order.pickupphone = data.phone1;
			}
			//$scope.order.pickupphone = $rootScope.session.user.phone; //test
		}
		//	Error Message
		$scope.message = [];
		
		// init function 
		$scope.init = function(){
			//	If verification code NOT exists then send to `Login screen`
			$rootScope.checkSession();
		};
		$scope.init();
		
		// Add Product Function 
		$scope.addProduct = function (product){
			console.log('test');
			console.log(product);
			for(var i in product)
			{
				var obj = product[i];
				var id = obj.product_id;
				var product_name = obj.product_name;
				var image = obj.image;
				var minivan = obj.minivan;
				var pickup = obj.pickup;
				var motorcycle = obj.motorcycle;
				var truck = obj.truck;
				var sedan = obj.sedan;
				
			}
			//var id = product.product_id;
			//console.log(product['product_id'],product['product_name'],product['image']);
			$scope.order.product[id] = new Object();

			$scope.order.product[id]['id'] = id;
			$scope.order.product[id]['name'] = product_name;
			$scope.order.product[id]['image'] = image;
			$scope.order.product[id]['assemble'] = false;
			
			$scope.order.product[id]['minivan'] = minivan==1?true:false;
			$scope.order.product[id]['pickup'] = pickup==1?true:false;
			$scope.order.product[id]['truck'] = truck==1?true:false;
			$scope.order.product[id]['motorcycle'] = motorcycle==1?true:false;
			$scope.order.product[id]['sedan'] = sedan==1?true:false;

			console.log($scope.order.product);
			//alert($scope.suggestVehicleType());
			if($scope.order.vehicletype != $scope.suggestVehicleType()){
				//if(confirm('Product does not support vehicle type? Do you want to change')){
					var vehicletype = $scope.suggestVehicleType(true);
					//console.log('sugg'+vehicletype);
					//alert('con'+vehicletype);
					//$scope.message[2] = 'Vehicle type "'+$scope.resource.vehicletype[vehicletype].text+'" selected';
				//}else{
				//	return false;	
				//}
			}
		}	//	Add Prodcut Over
		
		//	Suggest Vehicle Type 
		$scope.suggestVehicleType = function(set){
			var product = $scope.order.product;
			var vehicleType = 1;
			var count = new Object();
			count.minivan = 0;
			count.pickup = 0;
			count.truck = 0;
			count.motorcycle = 0;
			count.sedan = 0;
			for(i in product){
				if(product[i]['motorcycle']){
					count.motorcycle++;
				}else{
					// If not suitable for `motorcycle`
					if(product[i]['sedan']){
						count.sedan++;
					}else{
						// If not suitable for `sedan`
						if(product[i]['minivan']){
							count.minivan++;	
						}else{
							// If not suitable for `minivan`
							if(product[i]['pickup']){
								count.pickup++;	
							}else{
								// If not suitable for `pickup truck`
								if(product[i]['truck']){	count.truck++;	}
							}
						}
					}		
					
				}	
			}
			if(count.minivan > 0){	vehicleType = 1; }
			if(count.pickup > 0){	vehicleType = 2; }
			if(count.truck > 0){	vehicleType = 3; }
			if(count.motorcycle > 0){	vehicleType = 4; }
			if(count.sedan > 0){	vehicleType = 5; }
			
			if(typeof(set) != 'undefined' && set){
				$scope.order.vehicletype = vehicleType;
				//console.log($scope.order.vehicletype);
			}
			return vehicleType;
		}
		jQuery('body').on('click', '#btn', function() {
			jQuery('#auto').show();
			jQuery('#btn').hide();
		});
		
		
		jQuery('body').on('click', '#modalok', function() {
			
			  jQuery("#movir_error_step_3").empty();
			});
		
		
		//upload image
		
		$scope.uploadResult = [];
	 	$scope.onFileSelect = function($files,id) {
	var loading = jQuery('.progress_'+id+'','#movirAppCtrl').addClass('imageuploading');
	 $('#nextStep_3').attr("disabled", "disabled");

	
		  var $file = $files;
		  $upload.upload({
			url: api_url_2+"img.php",
			file: $file,
			//progress: function(e){console.log('progress');}
		  }).progress(function() {
			console.log('progress');
			
		})
		  .then(function(response) {
			img_path = response.data;
			$scope.imageupload(img_path,id);
			
		});

  }
  $scope.imageupload = function(img_path,id){
	  var action = 'uploadslaveimage_2';
			var request = new Object();
			request.userid = $rootScope.session.user.userid;
			request.token = $rootScope.session.user.token;		
			request.productid = id;
			request.vehicletype = $scope.suggestVehicleType(true);
			//alert(request.vehicletype);
			request.count = 1;
			request.img = img_path;
			//console.log(request);	
			
			
			$rootScope.callApi(action,request,function(payload){
				jQuery('.progress_'+id+'','#movirAppCtrl').removeClass('imageuploading');
				 $('#nextStep_3').removeAttr("disabled");
				//console.log(payload);
				
			});
  }
  

		// Remove Product Function 
		$scope.removeProduct = function (id){
			delete($scope.order.product[id]);
			delete($scope.order.assembleProduct[id]);
			$scope.suggestVehicleType(true);
		}
		
		// Add Assemble
		$scope.addAssembly = function(id){
			$scope.order.assembleProduct[id] = $scope.order.product[id]; // new Object();
			if($scope.order.product[id]['assemble']){
				$scope.order.product[id]['assemble'] = true;
			}else{
				$scope.removeAssembleProduct(id);
			}
		}

		// Remove Product Function 
		$scope.removeAssembleProduct = function (id){
			delete($scope.order.assembleProduct[id]);
			$scope.order.product[id]['assemble'] = false;
		}
		
		//	Set Pickup Address
		$scope.setPickupAddress = function(address){
			$scope.order.pickAddress = address;
			$scope.validateCity(address,function(payload,status){
				$scope.order.city = '';
				$scope.order.zipcode = '';
				$scope.message.pickupcity = '';
				if(payload.errFlag != 0){
					$scope.message.pickupcity = payload.errMsg;
					return false;
				}
				$scope.order.city = payload.data.city;
				$scope.order.zipcode = payload.data.zipcode;
			});
		}
		
		//	Set Drop Address
		$scope.setDropAddress = function(address){
			$scope.order.dropAddress = address;
			$scope.validateCity(address,function(payload,status){
				$scope.order.dropcity = '';
				$scope.order.dropzipcode = '';
				if(payload.errFlag != 0){
					$scope.message.dropcity = payload.errMsg;
					return false;
				}
				$scope.order.dropcity = payload.data.city;
				$scope.order.dropzipcode = payload.data.zipcode;
			});
		}
		
		//	Validate City function
		$scope.validateCity = function(address,callback){
			var geocoder = new google.maps.Geocoder();
			//var address = $scope.order.pickAddress;
			var action = 'validateCountry';
			geocoder.geocode( { 'address': address}, function(results, status) {
				if (status == google.maps.GeocoderStatus.OK) {
					var latitude = results[0].geometry.location.lat();
					var longitude = results[0].geometry.location.lng();
					var data = new Object();
					var user = $rootScope.session.user;
					data.userid = user.userid;
					data.token = user.token;
					data.latitude = latitude;
					data.longitude = longitude;
					$rootScope.callApi(action,data,function(payload,status){
						if(typeof(callback) == 'function'){
							callback(payload,status)	;
						}
						
					});
				}
			});
		}	//	Validate city function over 
		
		//	Get CC detail Id
		$scope.getCcDetailId = function(){
			console.log('11');
			var btn = jQuery('#btnAddPayment','#movirAppCtrl').button('loading');
			var action = 'ganarateccdetail';
			var data = new Object();
			data.userid = $rootScope.session.user.userid;
			data.token= $rootScope.session.user.token;
			
			var payment_modal =	jQuery('#movir_OrderPaymentModal','#movirAppCtrl');
			var payment_iframe = jQuery('#iframeOrderPayment','#movirAppCtrl')
			if($scope.order.ccdetailid){
				payment_iframe.attr('src',$scope.paymentUrl);
				payment_modal.modal('show');
				
				jQuery(btn).button('reset');
				return false;	
			}
			
			$rootScope.callApi(action,data,function(payload){
				jQuery(btn).button('reset');
				if(payload.errFlag != 0){ 
					$scope.message[3] = payload.errMsg; 
					return false; 
				}
				
				$scope.order.ccdetailid = payload.data.ccdetailid;
				$scope.paymentUrl = payload.data.url;
				
				payment_iframe.attr('src',$scope.paymentUrl);
				payment_modal.modal('show');
				
			});
		}
		
		//	check appointment date
		$scope.checkAppointmentDate = function(date){
			//alert(date);
			var action = 'checkappointmentdate';
			var request = new Object();
			request.userid = $rootScope.session.user.userid;
			request.token = $rootScope.session.user.token;
			request.date = date;
			//var loading = jQuery('.checkdateloading','#movirAppCtrl').addClass('checkloading');
			$rootScope.callApi(action,request,function(payload,status){
				$scope.order.appointmentdate = '';
				$scope.datetimeerror = '';
				if(payload.errFlag != 0){ 
				//jQuery('.checkdateloading','#movirAppCtrl').removeClass('checkloading');
					$scope.datetimeerror = payload.errMsg; 
					//alert($scope.message[3]);
					return false; 
				}
				$scope.order.appointmentdate = date;
			});
		}	//	check appointment date Over
		
		
		// Set Estimate Charge
		$scope.setEstimateCharge = function(charge){
			if(charge == false){
				$scope.estimateCharge = false;
				return false;	
			}
			$scope.estimateCharge = new Object();
			$scope.estimateCharge['transport_charge'] = charge.transport_charge;
			$scope.estimateCharge['discount'] = charge.discount;
			$scope.estimateCharge['vat_percentage'] = charge.vat_percentage;
			$scope.estimateCharge['vat'] = charge.vat;
			$scope.estimateCharge['price'] = charge.price;
			
			//	Datetime picker
			jQuery(function () {
				jQuery('#appointmentdate','#movirAppCtrl').datetimepicker({
          			format:'MM-DD-YYYY HH:mm:ss',
				}).on('dp.hide',function(e){
					var date = jQuery(this).val();
					$scope.checkAppointmentDate(date);
				});
			});
			var count = 0;
			for(i in $scope.order.product){
				$scope.order.product[i].index = ++count;
			}
			
		}	//	set Estimate charge over
		
		// Ganrate Request fuction (use to create reuqest for estimate price or order place api)
		$scope.ganarateRequest = function(placeOrder){
			var request = new Object();
			request.ordertype = $scope.order.ordertype;
			
			request.pickupaddress = $scope.order.pickAddress;
			request.dropaddress = $scope.order.dropAddress;
			request.vechicletype = $scope.order.vehicletype;
			request.pickupcity = $scope.order.city;
			request.pickupzipcode = $scope.order.zipcode;
			
			request.dropcity = $scope.order.dropcity;
			request.dropzipcode = $scope.order.dropzipcode;
			
			request.coupon = typeof($scope.order.coupon)!='undefined'?$scope.order.coupon:'';
			request.products = '';
			for(i in $scope.order.product){
				if(request.products == ''){
					request.products +=  i;
				}else{
					request.products +=  ','+i;
				}
			}
			if($scope.order.ordertype == 2){
				request.pickupfloor = $scope.order.pickFloor;
				request.dropfloor = $scope.order.dropFloor;
				
				if(request.pickupfloor == 'Elevator'){
					request.pickup_elevator = 1;
					request.pickupfloor = 0;
				}else{
					request.pickup_elevator = 0;
					request.pickupfloor = request.pickupfloor;
				}
				
				if(request.dropfloor == 'Elevator'){
					request.drop_elevator = 1;
					request.dropfloor = 0;
				}else{
					request.drop_elevator = 0;
					request.dropfloor = request.dropfloor;
				}
				
				//request.pickup_elevator = $scope.order.pickupElevator;
				//request.drop_elevator = $scope.order.dropElevator;
				request.assemble = $scope.order.isAssembly;
				if(request.assemble == 1){
					request.assemble_product = '';
					for(i in $scope.order.assembleProduct){
						if(request.assemble_product == ''){
							request.assemble_product +=  i;
						}else{
							request.assemble_product +=  ','+i;
						}
					}	
				}
			}
			// Not used yet 
			if($scope.order.ordertype == 2){
				request.hydraulic = 0;
				request.drop_hydraulic = 0;
			}
				
				
			if(typeof(placeOrder) != 'undefined' && placeOrder){
				request.userid = $rootScope.session.user.userid;
				request.token = $rootScope.session.user.token;
				
				//request.ccdetailid = $scope.order.ccdetailid;
				request.appointment_date = $scope.order.appointmentdate;
				request.ccdetailid = $scope.order.ccdetailid;
				//alert(request.ccdetailid);
				if(request.ccdetailid == false){ //change
					$scope.message[3] = "Please add your Credit Card details."; 
					jQuery("html, body").animate({ scrollTop: 0 }, "slow");
					
					return false; 
				}
				
				request.pickupname = $scope.order.pickupname;
				request.pickupphone = $scope.concode+$scope.order.pickupphone.replace(/-/g, "");
				request.dropname = $scope.order.dropname;
				request.dropphone = $scope.concode+$scope.order.dropphone.replace(/-/g, "");
				
				//	Appointment Type = 1. Do it your Self 2. Hire a Pro
				request.appointment_type = $scope.order.ordertype;
				//	Always Future order 
				request.ordertype = 2;
				
				
			}
			return request;
		}	// Ganrate Request fuction over 
		
		//	get Estimate charge 
		$scope.getEstimateCharge = function(){
			var btn = jQuery('#btnMovirSubmit','#movirAppCtrl').button('loading');
			$scope.setEstimateCharge(false);
			var request = $scope.ganarateRequest();
			
			
			$rootScope.callApi('getestimate',request,function(data){
				jQuery(btn).button('reset');
				if(data.errFlag != 0){ 
					$scope.message[3] = data.errMsg; 
					return false; 
				}
				var charges = data.data;
				$scope.setEstimateCharge(charges);	
			});
		}	//	get Estimate charge Order
		
		//	Verify Coupon code
		$scope.verifyCoupon = function(){
			var action = 'verifycoupon';
			var request = new Object();
			request.coupon = $scope.order.coupon;
			request.totalcharge = $scope.estimateCharge.price;
			
			$rootScope.callApi(action,request,function(payload){
				//console.log(payload);
				if(payload.errFlag != 0){ 
					$scope.message[3] = payload.errMsg; 
					return false; 
				}
				$scope.couponverified = true;
				$scope.getEstimateCharge();
				
			});
			
		}	//	verify Coupon code
		
		//	Next Step button click event
		initMap(initMapDirection);
		$scope.nextstep = function(step){
			
			var step1 = angular.element( document.querySelector( '#step1' ) );
			var step2 = angular.element( document.querySelector( '#step2' ) );
			var step3 = angular.element( document.querySelector( '#step3' ) );
			
			switch(step){
				
				case 1:
				
					//alert('step1');
					$scope.message[1] = '';
					step1.addClass('show');
					step2.removeClass('show');
					step2.addClass('hide');
					initMap(initMapDirection);
					break;
				case 2:
						
						if(! ($scope.order.ordertype==1 || $scope.order.ordertype==2)){ 
							$scope.message[1] = 'Please select Order type'
							return false;	
						
						}else if($scope.order.pickupphone=='' || $scope.order.pickupphone == null ){
							$scope.message[1] = 'Please enter Pickup location Phone no.';	
							return false;
						}
						else if($scope.order.pickAddress=='' || $scope.order.pickAddress==null ){
							$scope.message[1] = 'Please enter Pickup Address';
							return false;
						}
						
						else if($scope.order.dropphone=='' || $scope.order.dropphone == null){
							$scope.message[1] = 'Please enter Dropoff location Phone no.';	
							return false;
						}
						else if($scope.order.dropAddress=='' || $scope.order.dropAddress==null ){
							$scope.message[1] = 'Please enter Dropoff address';
							return false;
						}else if($scope.order.appointmentdate=='' || $scope.order.appointmentdate==null ){
							//alert($scope.order.appointmentdate);
							$scope.datetimeerror = 'Please enter Date and Time';
							return false;
						}else if(! $scope.order.city){
								$scope.message[1] = 'Please enter valid Address';
								return false;
						} else{
							var fullDate = new Date();
							var month = fullDate.getMonth()+1;
							var month1 = ("0" + month).slice(-2);
							var day = fullDate.getDate();
							var day1 = ("0" + day).slice(-2);
							var currentDate = month1 + "-" +day1+ "-" + fullDate.getFullYear() +" "+ (fullDate.getHours()+2)+":"+fullDate.getMinutes();
							//console.log(currentDate);
							//console.log( $scope.order.appointmentdate);
							if(currentDate > $scope.order.appointmentdate){
								$scope.datetimeerror = 'Minimum time of 2 hour for future order (according to israel standard time)';
								return false;
							}else{
								//$scope.message[1] = 'test';
							}
						}
					
						if($scope.order.ordertype == 2){
							
							if($scope.order.pickFloor == null || $scope.order.pickFloor == '' ){
									$scope.message[1] = 'Please Enter Pickup Floor/Elevator';
									return false;
								}
							if($scope.order.dropFloor == null || $scope.order.dropFloor == '' ){
									$scope.message[1] = 'Please Enter Drop Floor/Elevator';
									return false;
								}
						}
						
						//step1.addAttr('ng-hide');
						step1.removeClass('show');
						step1.addClass('hide');
						step2.addClass('show');
						step3.removeClass('show');
						step3.addClass('hide');
						$scope.message[1] = '';
						autocomplate_product();
						
						
						initMap(initMapDirection);
						
					break;
				case 3:
						var product_len = Object.keys($scope.order.product).length;
						if(product_len<=0){
							$scope.message[2] = 'Please select atleast one Product';
							return false;
						}
						if( $('#upload').val() == ""){
							 $scope.message[2] = 'Please upload photos of items';
						     return false;
						}
						if($scope.order.ordertype == 2){
							if($scope.order.pickFloor == null || $scope.order.pickFloor == '' ){
								$scope.message[2] = 'Please Enter Floor';
								return false;
							}
							if($scope.order.isAssembly == 1){
								var assemble_product_len = Object.keys($scope.order.assembleProduct).length;
								if(assemble_product_len<=0){
									$scope.message[2] = 'Please select Assembly Product';
									return false;
								}
							}
						}
						if($scope.order.vehicletype != $scope.suggestVehicleType()){
							//if(confirm('Product does not support vehicle type? Do you want to change')){
								var vehicle = new Object();
								var vehicletype = $scope.suggestVehicleType(true);
								//$scope.message[2] = 'Vehicle type "'+$scope.resource.vehicletype[vehicletype].text+'" selected';
								//console.log($scope.resource.vehicletype[vehicletype].text);
							//}else{
							//	return false;	
							//}
						}
						
						
						
						step2.removeClass('show');
						step2.addClass('hide');
						step3.removeClass('hide');
						step3.addClass('show');
						$scope.message[2] = '';
						initMap(initMapDirection);
						
						if($scope.order.ordertype == 2){
							if($scope.order.dropFloor == null || $scope.order.dropFloor == ''){
								$scope.message[3] = 'Please Enter Floors';
								return false;
							}
						}
						$scope.getEstimateCharge();
					break;
				
				default:
								
					break;	
			}
			
			$scope.openStep = step;
			
			$scope.complatedStep = step;	
			$scope.init();
		}	// next Step button Over
		
		
		
		//	Place Order 
		$scope.placeOrder = function(){
			var request = $scope.ganarateRequest(true);
			console.log(request);
			//alert(request);
			if(request == false){ //change
				//$scope.message[3] == "Please add your Credit Card details";
				return false;
			}
			var action = '';
			/*request.ccdetailid = 2; */// For Debug
			if($scope.order.ordertype == 1){
				// Do it your self	
				action = 'doityourself';
			}else if($scope.order.ordertype == 2){
				// Hire a pro
				action = 'hirepro';
			}
			var btn = jQuery('#btnMovirSubmit','#movirAppCtrl').button('loading');
			$rootScope.callApi(action,request,function(payload){
				console.log(payload);
				if(payload.errFlag != 0){ 
					$scope.message[3] = payload.errMsg;
					jQuery(btn).button('reset'); 
					jQuery("html, body").animate({ scrollTop: 0 }, "slow");
					return false; 
				}
				//console.log(payload.data.appointment_id);
				
				var ap_id = payload.data.appointment_id;
				var time = payload.data.timelimit;
				//console.log(payload.data.timelimit);
				//var eer = 1;
				var now = new Date();
				var exp = new Date(now.getTime() + 60*time*1000);
			
				$cookies.put('appointment_id', ap_id, {'expires': exp});
				$cookies.put('time', time, {'expires': exp});
				jQuery(btn).button('reset');
				
				//$scope.message[3] = '';
				//alert(payload.errMsg);
				//if(payload.errFlag != 0){ $scope.message[3] = payload.errMsg; return false; }
				$state.go('app.waiting');
			});
		}
		
		/*waiting time*/
		$scope.waiting_time = function(){
			var coo = $cookies.get('appointment_id');
			var tm = $cookies.get('time');
			var tmw = 0.2;
			//console.log(coo);
			jQuery("#ajax").append('<div class="loading-container"><div class="row"><div class="col-lg-6" style="margin-top:10%;margin-left:36%"><div class="animatecontainer" style="margin-left:10%"><div class="frame"><img src="http://movir.com/wp-content/plugins/movir/src/image/imglogo1.png" /></div><div class="frame" style="z-index:5"><img src="http://movir.com/wp-content/plugins/movir/src/image/imglogo2.png" /></div></div><p class="text-center text-info lead" style="margin-top:10px;position:absolute;top:200px">Please wait, We are locating your nearest Personal Mover…</p><p class="timer" style="margin-top: 10%; margin-left: 10%;" data-minutes-left='+tm+'></p></div></div><div class="row"><div class="col-lg-6 ajax" style="margin-top:3%;margin-left:30%"></div></div></div>');
			var str="<script type='text/javascript' src='http://movir.com/wp-content/plugins/movir/src/js/jquery.simple.timer.js?ver=4.5.2'>";
			str+="<";
			str+="/script>";
			str+='<script> check_status();  function check_status(){ var order = '+coo+';check(order);setInterval(function() {interval = check(order);}, 5000);function check(ordert){ $.ajax({type: "POST",url: "http://whiteglovesme.com/admin/demo.php",data: {ordert:ordert},success: function(data) {console.log(data); if(data != 2){}else{ jQuery(".ajax").empty(); jQuery(".ajax").append(\'<div class="checkmark-circle" style="margin-left: 32%;"><div class="background"></div><div class="checkmark draw"></div></div><p class="text-center text-info lead" style="margin-top:10px;position:absolute;top:200px;font-weight:bold;color:#2ecc71;font-size:25px;margin-left:21%">Your order has been Accepted!!</p>\');setTimeout( function(){ remove();},1500 );   }  }}); } }   function remove(){  window.location.href = "http://movir.com/user-order/"; jQuery("#ajax").empty(); } jQuery(".timer").startTimer({onComplete: function(element){setTimeout( function(){ remove();},2500 );jQuery(".ajax").append(\'<div class="checkmark-circle" style="margin-left: 32%;"><div class="background2"></div><div class="checkmark3 draw3"></div><div class="checkmark2 draw2"></div></div><p class="text-center text-info lead" style="margin-top:10px;position:absolute;top:200px;font-weight:bold;color:#e74c3c;font-size:25px;margin-left:21%">Your order has been expired!!</p>\');}});';
			
			str+="<";
			str+="/script>";
			jQuery("#ajax").append(str);
			
		}
		/*end*/
		
}]);	//	Order Place Controller over


//	Order History
movirapp.controller('ctrlOrderhistory',['$rootScope','$scope','$state',function($rootScope,$scope,$state){
	$scope.orders = new Object()
	$scope.message = new Object();
	$scope.reorder = new Object();
	$scope.reorder.id = false;
	$scope.reorder.appointmentdate = '';
	$scope.estimateCharge = false;
	$scope.paymentUrl = false;
	
	// Init function
	$scope.init = function(){
		var action = 'getappointments';
		var request = new Object();
		
		request.userid = $rootScope.session.user.userid;
		request.token  = $rootScope.session.user.token;
		var loading = jQuery('.checkloading1','#movirAppCtrl').addClass('checkloading');
		$rootScope.callApi(action,request,function(payload){
			jQuery('.checkloading1','#movirAppCtrl').removeClass('checkloading');
			if(payload.errFlag != 0){ $scope.message[0] = payload.errMsg; return false; }
			var orders = payload.data;
			
			for( i in orders ){
				//	vehicle type class
				if(orders[i].vechicle_type == 1){
					orders[i].vehicle_class = 'minivan';
				}else if(orders[i].vechicle_type == 2){
					orders[i].vehicle_class = 'pickuptruck';
				}else if(orders[i].vechicle_type == 3){
					orders[i].vehicle_class = 'truck';
				}else if(orders[i].vechicle_type == 4){
					orders[i].vehicle_class = 'motorcycle';
				}else if(orders[i].vechicle_type == 5){
					orders[i].vehicle_class = 'sedan';
				}
				
				//	Driver text
				if(orders[i].mas_id == 0){
					orders[i].driver_text = 'No mover assign yet';
				}else{
					orders[i].driver_text = 'Mover : '+orders[i].mas_name;	
				}
				
				//	Date text
				var date = orders[i].appointment_date;	
				date = date.replace(' ','T');
				orders[i].date_text = new Date(date).toLocaleFormat();
				
				//	Label 
				orders[i].status_class = '';
				orders[i].status_text = '';
				if(orders[i].status == 1 || orders[i].status == 2){
					orders[i].status_class = 'label-warning pending';
					orders[i].status_text = 'PendingOrder';
				}else if(orders[i].status == 3 || orders[i].status == 4 || orders[i].status == 5){
					orders[i].status_class = 'label-danger cancled';
					orders[i].status_text = 'CanceledOrder';
				}else if(orders[i].status == 6 || orders[i].status == 7 || orders[i].status == 8){
					orders[i].status_class = 'label-info running';
					orders[i].status_text = 'RunningOrder';
				}else if(orders[i].status == 9){
					orders[i].status_class = 'label-success completed';
					orders[i].status_text = 'CompletedOrder';
				}else if(orders[i].status == 10){
					orders[i].status_class = 'label-danger exipry';
					orders[i].status_text = 'ExpiredOrder';
				}
				
				//	Reorder Status
				orders[i].canreorder = false;
				if(orders[i].status == 4 || orders[i].status == 10){
					orders[i].canreorder = true;
				}
				
				//	Amount text
				orders[i].amount_text = orders[i].amount+' ILS';
			}
			$scope.orders = orders;
		})
	}; 
	
	$scope.init();	
	
	$scope.orderDetail = function(orderid){
		$state.go('app.orderdetail',{'orderid':orderid});
	}
	
	//	check appointment date
	$scope.checkAppointmentDate = function(date){
		//alert(1);
		var action = 'checkappointmentdate';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		request.date = date;
		var loading = jQuery('.checkdateloading','#movirAppCtrl').addClass('checkloading');
		$rootScope.callApi(action,request,function(payload,status){
			jQuery('.checkdateloading','#movirAppCtrl').removeClass('checkloading');
			$scope.reorder.appointmentdate = '';
			//$scope.message[1] = '';
			//$scope.message[1] = payload.errMsg;
			if(payload.errFlag == 1){ 
				$scope.message[1] = payload.errMsg;
				 return false; 
		    }else{
				$scope.message[1] = '';
				}
			$scope.reorder.appointmentdate = date;
		});
	}	//	check appointment date Over
	
	//	Get CC detail Id
	$scope.getCcDetailId = function(){
		console.log('22');
		var btn = jQuery('#btnAddPayment','#movirAppCtrl').button('loading');
		var action = 'ganarateccdetail';
		var data = new Object();
		data.userid = $rootScope.session.user.userid;
		data.token= $rootScope.session.user.token;
		
		var payment_modal =	jQuery('#movir_OrderPaymentModal','#movirAppCtrl');
		var payment_iframe = jQuery('#iframeOrderPayment','#movirAppCtrl')
		if($scope.reorder.ccdetailid){
			payment_iframe.attr('src',$scope.paymentUrl);
			payment_modal.modal('show');
			jQuery(btn).button('reset');
			return false;	
		}
		
		$rootScope.callApi(action,data,function(payload){
			jQuery(btn).button('reset');
			if(payload.errFlag != 0){ 
				$scope.message[3] = payload.errMsg; 
				return false; 
			}
			$scope.reorder.ccdetailid = payload.data.ccdetailid;
			$scope.paymentUrl = payload.data.url;
			payment_iframe.attr('src',$scope.paymentUrl);
			payment_modal.modal('show');
		});
	}	//	Get CC Detail
	
	//	open modal box
	$scope.openDatechecker = function(orderid){
		$scope.message[1] = '';
		$scope.estimateCharge = false;
		$scope.reorder.appointmentdate = '';
		$scope.reorder.id = orderid;
		jQuery('#modalReorder').modal('show');
		//	Datetime picker
		jQuery(function () {
			jQuery('#reorderappointmentdate','#movirAppCtrl').datetimepicker({
				format:'MM-DD-YYYY HH:mm',
				 stepping: 30
			}).on('dp.hide',function(e){
				var date = jQuery(this).val();
				$scope.checkAppointmentDate(date);
			});
			
			/*jQuery('#appointmentdate1','#movirAppCtrl').datetimepicker({
				  format:'MM-DD-YYYY',
				 // minDate: moment(),
				  //startDate: new Date(),
				}).on('dp.change',function(e){
					
					var time1 = jQuery('#appointmenttime1').val();
					if(time1 == ""){
						//alert("Please enter Date");
						//jQuery('#movir_error_step_1').text("Please enter Time");
						//return false;
					}else{
						var date1 = jQuery('#appointmentdate1').val();
						var date = date1+" "+time1;
						var datetest = jQuery('#reorderappointmentdate').val(date);
						var scope = angular.element(document.getElementById('movirAppCtrl')).scope();
						scope.$apply(function(){
							scope.$$childHead.checkAppointmentDate(date);

						});
					}
				});
				jQuery('#appointmenttime1','#movirAppCtrl').datetimepicker({
				  format:'HH:mm',
				 
				}).on('dp.change',function(e){
					
					var date1 = jQuery('#appointmentdate1').val();
					if(date1 == ""){
						//alert("Please enter Date");
						//jQuery('#movir_error_step_1').text("אנא הזן/ני מועד הזמנה");
						return false;
					}else{
						var time1 = jQuery('#appointmenttime1').val();
						var date = date1+" "+time1;
						var datetest = jQuery('#reorderappointmentdate').val(date);
						var scope = angular.element(document.getElementById('movirAppCtrl')).scope();
						scope.$apply(function(){
							scope.$$childHead.checkAppointmentDate(date);

						});
					}
				});*/

		});
	}
	
	//	Get Estimate function
	$scope.getEstimate = function(){
		var action = "reuqestreorder";
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		request.appointment_id = $scope.reorder.id;
		request.datetime = $scope.reorder.appointmentdate;
		/*alert(request.datetime);
		if(request.datetime == ''){
			return false;
			}*/
		var button = jQuery('#getEstimateReorder','#movirAppCtrl').button('loading');
		$rootScope.callApi(action,request,function(payload){
			jQuery(button).button('reset');
			$scope.estimateCharge = false;
			$scope.message[1] = '';
			if(payload.errFlag != 0){ $scope.message[1] = payload.errMsg; return false; }
			$scope.estimateCharge = payload.data;
		});
	}
	
	//	Place Order 
	$scope.placeReorder = function(){
		var action = "reorder";
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		request.appointment_id = $scope.reorder.id;
		request.ccdetailid = $scope.reorder.ccdetailid;
		if(request.ccdetailid == '' || typeof(request.ccdetailid)=='undefined'){
			$scope.message[1] = "Please add Credit Card Details";
			return false;
		}
		request.datetime = $scope.reorder.appointmentdate;
	
		var button = jQuery('#placeReorder','#movirAppCtrl').button('loading');
		$rootScope.callApi(action,request,function(payload){
			console.log(payload);
			jQuery(button).button('reset');
			$scope.message[1] = '';
			if(payload.errFlag != 0){ $scope.message[1] = payload.errMsg; return false; }
			jQuery('#modalReorder').modal('hide');
			//setInterval(function(){ $state.go('app.waiting'); }, 1000);
			//$state.go('app.waiting'); 
			var appointment_id = payload.data.appointment_id;
			$state.go('app.orderdetail',{'orderid':appointment_id});
			
		});
	}

}]);	// Order History

//	Order detail controller
movirapp.controller('ctrlOrderdetail',['$rootScope','$scope','$state','$stateParams',function($rootScope,$scope,$state,$stateParams){
	$scope.order = new Object();
	$scope.message = new Object();
	$scope.init = function(){
		//var action = 'getappointment';
		var action = 'getappointmentcustomer';
		var request = new Object;
		request.userid = $rootScope.session.user.userid;
		request.token  = $rootScope.session.user.token;
		request.appointmentid = $stateParams.orderid;
		var loading = jQuery('.allorderdetail','#movirAppCtrl').addClass('loading');
		$rootScope.callApi(action,request,function(payload){
			jQuery('.allorderdetail','#movirAppCtrl').removeClass('loading');
			if(payload.errFlag != 0){ $state.go('app.orderhistory'); return false; }
			if(payload.data.slave_id != $rootScope.session.user.userid){
				$state.go('app.orderhistory'); 
				return false;
			}
			
			var product_list = new Object();
			var product = payload.data.product;
			for(i in payload.data.product){
				var idx = payload.data.product[i].product_id;
				product_list[idx] = new Object();
				product_list[idx] = payload.data.product[i];
				product_list[idx].index = parseInt(i) + 1;
				product_list[idx].assemble = false;
				
			}
			for(i in payload.data.assemble_product){
				var idx = payload.data.assemble_product[i].product_id;
				product_list[idx].assemble = true;
			}
			$scope.order = payload.data;
			
			$scope.order.product_list = product_list;
			var date = $scope.order.appointment_date;
			date = date.replace(' ','T')
			$scope.order.date_text = new Date(date).toLocaleFormat();
			
			
			var status_class = '';
			var status_text = '';
			var status = payload.data.status;
			if(status == 1 || status == 2){
				status_class = 'label-warning pending';
				status_text = 'PendingOrder';
			}else if(status == 3 || status == 4 || status == 5){
				status_class = 'label-danger cancled';
				status_text = 'CanceledOrder';
			}else if(status == 6 || status == 7 || status == 8){
				status_class = 'label-info running';
				status_text = 'RunningOrder';
			}else if(status == 9){
				status_class = 'label-success completed';
				status_text = 'CompletedOrder';
			}else if(status == 10){
				status_class = 'label-danger exipry';
				status_text = 'ExpiredOrder';
			}
			$scope.order.status_class = status_class;
			$scope.order.status_text = status_text;
		});
		
	}
	$scope.init();
	
	$scope.cancleOrder = function(){
		var action = 'cancleappointment';
		var request = new Object;
		request.userid = $rootScope.session.user.userid;
		request.token  = $rootScope.session.user.token;
		request.appointmentid = $scope.order.appointment_id;
		
		var button = jQuery('#btnCancleOrder').button('loading');
		$rootScope.callApi(action,request,function(payload){
			jQuery(button).button('reset');
			if(payload.errFlag != 0){  
				$scope.message = payload.errMsg;
				return false; 
			}
			$state.go('app.orderhistory');
		});
	}
}]);	//	Order detail controller over


//	Invoice Listing
movirapp.controller('ctrlInvoice',['$rootScope','$scope','$state',function($rootScope,$scope,$state){
	$scope.init = function(){
		var action = 'invoicelist';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token  = $rootScope.session.user.token;
		$rootScope.callApi(action,request,function(payload){
			if(payload.errFlag != 0){ $scope.message[0] = payload.errMsg; return false; }
			var invoicelist = payload.data;
			
			for(i in invoicelist){
				invoicelist[i].amount_text = invoicelist[i].amount+' ILS';
				
				invoicelist[i].status_text = '';
				invoicelist[i].status_class = '';
				if(invoicelist[i].status == 1){
					invoicelist[i].status_text = 'Pending';
					invoicelist[i].status_class = 'label-warning';
				}else if(invoicelist[i].status == 2){
					invoicelist[i].status_text = 'Cancled';
					invoicelist[i].status_class = 'label-info';
				}else if(invoicelist[i].status == 3){
					invoicelist[i].status_text = 'NotPaid';
					invoicelist[i].status_class = 'label-danger';
				}else if(invoicelist[i].status == 4){
					invoicelist[i].status_text = 'Completed';
					invoicelist[i].status_class = 'label-success';
				}
			}
			
			$scope.invoicelist = invoicelist;
			//console.log(payload);
		});
	}
	$scope.init();
	
	$scope.invoiceDetail = function(invoiceid){
		$state.go('app.invoicedetail',{'invoiceid':invoiceid});
		return 
	}
}]);	//	invoice listing complate

//	invoice Detail function 
movirapp.controller('ctrlInvoicedetail',['$rootScope','$scope','$stateParams','$state',function($rootScope,$scope,$stateParams,$state){
	$scope.tip = 0;
	$scope.message = new Object();
	$scope.init = function(){
		var action = 'invoicedetail';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token  = $rootScope.session.user.token;
		request.invoiceid = $stateParams.invoiceid;
		$scope.message = new Object();
		$rootScope.callApi(action,request,function(payload){
			if(payload.errFlag != 0){ 
				$state.go('app.invoice');
				$scope.message[0] = payload.errMsg; 
				return false; 
			}
			var invoice = payload.data;
			$scope.tip = parseInt(invoice.tip);
			invoice.vat_amount = 0;
			invoice.transport_charge = 0;
			invoice.without_tip_amount = invoice.amount - $scope.tip; 
			invoice.total_vat_percentage = 100 + parseInt(invoice.vat);
			invoice.transport_charge = ( invoice.without_tip_amount / invoice.total_vat_percentage ) * 100;
			invoice.transport_charge = invoice.transport_charge + parseInt(invoice.discount);
			invoice.vat_amount = (invoice.transport_charge * invoice.vat) / 100;
			
			invoice.vat_amount = (invoice.vat_amount).toFixed(2);
			invoice.transport_charge = (invoice.transport_charge).toFixed(2);
			
			invoice.status_text = '';
			invoice.status_class = '';
			if(invoice.status == 1){
				invoice.status_text = 'Pending';
				invoice.status_class = 'label-warning';
			}else if(invoice.status == 2){
				invoice.status_text = 'Cancled';
				invoice.status_class = 'label-info';
			}else if(invoice.status == 3){
				invoice.status_text = 'Not Paid';
				invoice.status_class = 'label-danger';
			}else if(invoice.status == 4){
				invoice.status_text = 'Completed';
				invoice.status_class = 'label-success';
			}
			
			
			$scope.invoice = invoice;
		});
	}
	$scope.init();
	
	$scope.makePayment = function(){
		var action = 'customermakepayment';	
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token  = $rootScope.session.user.token;
		request.appointment_id = $scope.invoice.appointment_id;
		request.tip = $scope.tip;
		
		var button = jQuery('#btnMakepayment').button('loading');
		$rootScope.callApi(action,request,function(payload){
			jQuery(button).button('reset');
			if(payload.errFlag != 0){ 
				$scope.message[0] = payload.errMsg; 
				return false; 
			}
			var invoice = payload.data;
			$state.go('app.rating',{'appointmentid':request.appointment_id});
		});
	}
}]);		//	Invoice detail Over 


//	User Account 
/*movirapp.controller('ctrlAccount',['$rootScope','$scope',function($rootScope,$scope){
	$scope.message = new Object();
	$scope.init = function(){
		$scope.user = $rootScope.session.user;
	}
	$scope.init();
	
	$scope.update = function(){
		var action = 'updateslave';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		request.fname = $scope.user.username;
		//alert($scope.user.profilepic);
		//request.profilePic = $scope.user.profilepic;
		
		var button = jQuery('#profileupdate','#movirAppCtrl').button('loading');
		$rootScope.callApi(action,request,function(payload){
			jQuery(button).button('reset');
			if(payload.errFlag != 0){
				$scope.message[0] = payload.errMsg;
				return false;
			}
			$rootScope.saveSession();
		});
	}
}]);	//	User Account*/

//	User Account 
movirapp.controller('ctrlAccount',['$rootScope','$scope','$upload',
	function($rootScope,$scope,$upload){
	$scope.message = new Object();
	$scope.init = function(){
		$scope.user = $rootScope.session.user;
		console.log($scope.user);
	}
	$scope.init();
	
	//upload image
		
		
	 	$scope.onFileSelect = function($files) {
			var loading = jQuery('.progress1','#movirAppCtrl').addClass('imageuploading');
		  var $file = $files;
		  $upload.upload({
			url: api_url_2+"img.php",
			file: $file,
			//progress: function(e){console.log('progress');}
		  }).progress(function() {
			console.log('progress');
			
		})
		  .then(function(response) {
			img_path = response.data;
			//console.log(img_path);
			jQuery('.progress1','#movirAppCtrl').removeClass('imageuploading');
			//$scope.imageupload(img_path);
			
		});

  }

	$scope.update = function(){
		var action = 'updateslaveweb';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		request.fname = $scope.user.username;
		//alert(img_path);
		request.profilePic = img_path;
		
		var button = jQuery('#profileupdate','#movirAppCtrl').button('loading');
		$rootScope.callApi(action,request,function(payload){
			$rootScope.session.user.profilePic = 'http://whiteglovesme.com/'+img_path;
			jQuery(button).button('reset');
			if(payload.errFlag != 0){
				$scope.message[0] = payload.errMsg;
				return false;
			}
			$rootScope.saveSession();
		});
	}
}]);	//	User Account

//	Driver Rating Controller
movirapp.controller('ctrlRating',['$rootScope','$scope','$state','$stateParams',function($rootScope,$scope,$state,$stateParams){
	$scope.message = new Object();
	$scope.rate = 5;
	$scope.init = function(){
		//var action = 'getappointment';
		var action = 'getappointmentcustomer';
		var request = new Object();
		request.appointmentid = $stateParams.appointmentid;
		$rootScope.callApi(action,request,function(payload){
			if(payload.errFlag != 0){
				$state.go('app.invoice');
				return false;
			}
			var data = payload.data;
			var start_date = data.start_date;
			var complete_date = data.complete_date;
			
			start_date = start_date.replace(' ','T');
			complete_date = complete_date.replace(' ','T');
			
			data.start_date_string = new Date(start_date).toLocaleFormat();
			data.complete_date_string = new Date(complete_date).toLocaleFormat();
			$scope.order = data;
		});
	}
	$scope.init();
	
	$scope.cancle = function(){ $state.go('app.invoice'); }
	
	$scope.sendRating = function(){
		var action = 'driverrating';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		request.appointment_id = $scope.order.appointment_id;
		request.rate = $scope.rate;
		if($scope.comment != ''){
			request.comment = $scope.comment;
		}
		
		$rootScope.callApi(action,request,function(payload){
			if(payload.errFlag != 0){
				$scope.message[0] = payload.errMsg;
				return false;
			}
			$state.go('app.invoice');
		});
	}
	
}]);	//	Driver Rating Controller Over


//	Live track url

movirapp.controller('ctrlLivetrack',['$rootScope','$scope','$state',function($rootScope,$scope,$state){
	$scope.message = new Object();
	$scope.markers = [];
	//$scope.marker = '';
	$scope.init = function(){
		var action = 'getappointmenttrack';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		$rootScope.callApi(action,request,function(payload){
			//console.log(payload);
			if(payload.errFlag != 0){
				//$scope.message[0] = payload.errMsg;
				$scope.message[0] = 'Live Tracking Not Available';
				//setInterval(function(){ $state.go('app'); },2000);	
				//$state.go('app');
				return false;
			}
			var order = payload.data;
			
			order.status_date_string = new Object();
			order.status = parseInt(order.status);
			order.latitude = parseFloat(order.latitude);
			order.longitude = parseFloat(order.longitude);
			for(var i=6; i<= order.status; i++){
				order.status_date_string[i] = $scope.convertDateToString(order.status_time[i]);
			}
			$scope.order = order;
			
			$scope.initMap();
			
			//	If order is hire a pro then check for additional services
			if($scope.order.order_type == 2){
				action = 'getappointmentcustomer';
				request.appointmentid = $scope.order.appointment_id;
				$rootScope.callApi(action,request,function(payload){
					var product_list = new Object();
					var product = payload.data.product;
					for(i in payload.data.product){
						var idx = payload.data.product[i].product_id;
						product_list[idx] = new Object();
						product_list[idx] = payload.data.product[i];
						product_list[idx].index = parseInt(i) + 1;
						product_list[idx].assemble = false;
						
					}
					for(i in payload.data.assemble_product){
						var idx = payload.data.assemble_product[i].product_id;
						delete (product_list[idx]);
					}
					$scope.product_list = product_list;
				});
			}
		});
	}	
	
	$scope.init();
	
	
	$scope.convertDateToString = function(date){
		date = date.replace(' ','T');
		date = new Date(date).toLocaleFormat();
		return date;
	}
	
	$scope.initMap = function(){
		initMap(function(){
			$scope.map = new google.maps.Map(document.getElementById('mapLivetrack'), {
				zoom: 10,
				center: {lat: $scope.order.latitude, lng: $scope.order.longitude}
			});
			$scope.addMarker($scope.order.latitude,$scope.order.longitude,'Driver Location');
			$scope.addMarker($scope.order.pickup_latitude,$scope.order.pickup_longitude,'Pickup Location');
			$scope.addMarker($scope.order.drop_latitude,$scope.order.drop_lonitude,'Drop Location');
		});
	}
	
	$scope.addMarker = function(lat,lng,label) {
		var latlong = new google.maps.LatLng(lat,lng);
		marker = new google.maps.Marker({
			position: latlong,
			map: $scope.map,
			nimation: google.maps.Animation.DROP,
			title:label,
			label:label,
			//description:'Description',
		});
		($scope.markers).push(marker);
	}
	setInterval(function(){ $scope.livemarker(); },5000);	
	
	$scope.livemarker = function(){
		var action = 'getappointmenttrack';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		$rootScope.callApi(action,request,function(payload){
				console.log(payload);
			if(payload.errFlag == 0){
				var order = payload.data;
			
			order.status_date_string = new Object();
			order.status = parseInt(order.status);
			order.latitude = parseFloat(order.latitude);
			order.longitude = parseFloat(order.longitude);
			for(var i=6; i<= order.status; i++){
				order.status_date_string[i] = $scope.convertDateToString(order.status_time[i]);
			}
			$scope.order = order;
			console.log($scope.order.status,$scope.order.latitude,$scope.order.longitude);
				$scope.DeleteMarker();
				$scope.addMarker($scope.order.latitude,$scope.order.longitude,'Driver Location');
				//$scope.addMarker($scope.order.pickup_latitude,$scope.order.pickup_longitude,'Pickup Location');
			    //$scope.addMarker($scope.order.drop_latitude,$scope.order.drop_lonitude,'Drop Location');
			}
		});
	}
	$scope.DeleteMarker = function DeleteMarker() {
            /* for (var i = 0; i < $scope.markers.length; i++) {
				$scope.markers[i].setMap(null);
			}
			 $scope.markers = [];
			 */
			  for (var i = 0; i < $scope.markers.length; i++) {
            if ($scope.markers[i].label == 'Driver Location') {             
                $scope.markers[i].setMap(null);
                $scope.markers.splice(i, 1);
                return;
            }
        }
			
    }
	//	Additional services
	$scope.submitAdditionalServices = function(){
		var action = 'additionalservice';
		var request = new Object();
		var product_list = jQuery('input[name="assemble_product"]:checked').serializeArray();
		var assemble_product_string = '';
		for(i in product_list){
			var id = product_list[i].value;
			delete($scope.product_list[id]);	// remove added product from list 
			if(assemble_product_string == ''){
				assemble_product_string = id;
			}else{
				assemble_product_string += ','+id;
			}
		}

		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		request.appointment_id = $scope.order.appointment_id;
		request.assemble_product = assemble_product_string;
		
		var button = jQuery('#btnSubmitAdditionalServices','#movirAppCtrl').button('loading');
		$rootScope.callApi(action,request,function(payload){
			jQuery(button).button('reset');
			/*if(payload.errFlag != 0){
				$scope.message[1] = payload.errMsg;
				return false;
			}*/
			jQuery('#modalAdditionalServices','#movirAppCtrl').modal('hide');
			$scope.message[0] = 'Order Successfully updated';
		})
	}
	
	
	/*end*/
	
}]);
